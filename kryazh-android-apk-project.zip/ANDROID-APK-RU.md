# Кряж — Android APK

Это подготовленная Android-обёртка для игры из проекта. Она собирает веб-игру в APK через Capacitor; игровой код сохранён.

## Как получить APK без установки программ на компьютер

1. Создайте приватный или публичный репозиторий GitHub и загрузите туда содержимое этой папки.
2. Откройте вкладку **Actions** в репозитории и запустите workflow **Build Android APK** (кнопка **Run workflow**). При первом запуске GitHub может попросить разрешить Actions.
3. После завершения откройте запуск workflow, раздел **Artifacts**, скачайте `kryazh-android-apk.zip` и распакуйте его.
4. Установите `app-debug.apk` на Android. Если телефон спросит, разрешите установку приложений из этого источника.

Workflow собирает APK для тестовой установки. Для публикации в Google Play понадобится подписанный release APK/AAB.

## Локальная сборка

Нужны Node.js 22, Java 21, Android SDK и Gradle.

```bash
npm install
npm run build:web
npx cap add android
npx cap sync android
cd android
gradle assembleDebug
```

APK будет в `android/app/build/outputs/apk/debug/app-debug.apk`.

## Примечание

В текущем окружении нет Android SDK, поэтому готовый бинарный APK здесь собрать нельзя. Этот комплект содержит конфигурацию и GitHub Actions workflow, который соберёт APK в облаке. После первого запуска workflow можно скачать APK из Artifacts.
