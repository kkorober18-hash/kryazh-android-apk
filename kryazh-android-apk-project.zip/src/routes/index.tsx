import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { Hud } from "@/components/hud";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    let stop = () => {};
    let cancel = false;
    void import("@/game/engine").then((mod) => {
      if (cancel) return;
      stop = mod.mount(canvas);
    });
    return () => {
      cancel = true;
      stop();
    };
  }, []);

  return (
    <main className="game-root">
      <canvas ref={ref} className="game-canvas" />
      <Hud />
    </main>
  );
}
