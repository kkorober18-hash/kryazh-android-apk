import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import {
  Axe,
  Backpack,
  ClipboardList,
  Coins,
  Footprints,
  Hammer,
  Map,
  Menu,
  TreePine,
  Tractor,
  Users,
  Volume2,
  VolumeX,
  Warehouse,
  X,
} from "lucide-react";
import { fmt } from "@/game/balance";
import { audio } from "@/game/audio";
import { bus, type Snap, type UpgradeId } from "@/game/store";

const ICONS: Record<UpgradeId, typeof Axe> = {
  axe: Axe,
  boots: Footprints,
  pack: Backpack,
  workers: Users,
  tractor: Tractor,
  sawmill: Warehouse,
};

export function Hud() {
  const snap = useSyncExternalStore(bus.subscribe, bus.getSnapshot, bus.getSnapshot);
  return (
    <div className="hud">
      {snap.phase === "title" ? <Title snap={snap} /> : <Play snap={snap} />}
      {snap.panel !== "none" ? <Sheet snap={snap} /> : null}
    </div>
  );
}

function Title({ snap }: { snap: Snap }) {
  return (
    <div className="title-screen">
      <div className="title-card">
        <p className="kicker">Лесопильный бизнес</p>
        <h1>Кряж</h1>
        <p className="lede">Руби лес, продавай брёвна, открывай новые делянки и расти бригаду.</p>
        <ul className="steps">
          <li>
            <TreePine />
            Подойди к дереву — рубка начинается сама.
          </li>
          <li>
            <Coins />
            Отнеси брёвна к синей машине и получи деньги.
          </li>
          <li>
            <Map />
            Копи на берёзу и кедр, нанимай людей и трактор.
          </li>
        </ul>
        {snap.bootError ? <p className="boot-error">{snap.bootError}</p> : null}
        <div className="btn-row">
          <button
            className="primary"
            type="button"
            onClick={() => {
              audio.unlock();
              bus.push({ t: "start", fresh: !snap.hasSave });
            }}
          >
            {snap.hasSave ? "Продолжить смену" : "Начать смену"}
          </button>
          {snap.hasSave ? (
            <button
              className="ghost"
              type="button"
              onClick={() => {
                audio.unlock();
                bus.push({ t: "start", fresh: true });
              }}
            >
              Новая делянка
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function Play({ snap }: { snap: Snap }) {
  const [pop, setPop] = useState(false);
  const prev = useRef(snap.money);
  useEffect(() => {
    if (snap.money !== prev.current) {
      prev.current = snap.money;
      setPop(true);
      const id = window.setTimeout(() => setPop(false), 220);
      return () => window.clearTimeout(id);
    }
  }, [snap.money]);

  const pct = Math.max(0, Math.min(100, (snap.levelInto / Math.max(1, snap.levelNeed)) * 100));

  return (
    <>
      <div className="topbar">
        <div className="level-wrap">
          <div className="level-badge" aria-label={`Уровень ${snap.level}`}>
            {snap.level}
          </div>
          <div className="level-meta">
            <span>Уровень</span>
            <div className="level-track">
              <i style={{ width: `${pct}%` }} />
            </div>
          </div>
        </div>
        <div className={pop ? "money pop" : "money"}>
          <Coins />
          {fmt(snap.money)} ₽
        </div>
      </div>

      <div className="quests">
        {snap.active.length === 0 ? (
          <article className="quest">
            <header>
              <ClipboardList />
              Смена закрыта
            </header>
            <p>Все подрядные задания выполнены. Лес всё ещё приносит деньги.</p>
          </article>
        ) : (
          snap.active.map((quest) => {
            const qpct = Math.max(0, Math.min(100, (quest.cur / Math.max(1, quest.goal)) * 100));
            return (
              <article className="quest" key={quest.id}>
                <header>
                  <ClipboardList />
                  {quest.title}
                </header>
                <p>{quest.detail}</p>
                <div className="bar">
                  <i style={{ width: `${qpct}%` }} />
                </div>
                <div className="count">
                  {quest.cur}/{quest.goal}
                </div>
              </article>
            );
          })
        )}
      </div>

      <div className="rail">
        <button className="rail-btn" type="button" onClick={() => bus.push({ t: "panel", panel: "upgrade" })}>
          <Hammer />
          <span>Апгрейд</span>
        </button>
        <button className="rail-btn" type="button" onClick={() => bus.push({ t: "panel", panel: "map" })}>
          <Map />
          <span>Карта</span>
        </button>
        <button className="rail-btn" type="button" onClick={() => bus.push({ t: "panel", panel: "quest" })}>
          <ClipboardList />
          <span>Задания</span>
        </button>
        <button className="rail-btn" type="button" onClick={() => bus.push({ t: "panel", panel: "menu" })}>
          <Menu />
          <span>Меню</span>
        </button>
      </div>

      {snap.hint ? <div className="hint">{snap.hint}</div> : null}
      {snap.toast ? (
        <div className="toast" key={snap.toastId}>
          {snap.toast}
        </div>
      ) : null}

      <div className="bottom-bar">
        <Joystick />
        <div className="carry">
          <b>
            {snap.carry}/{snap.carryMax}
          </b>
          <span>{snap.stock > 0 ? `рюкзак · склад ${snap.stock}` : "в рюкзаке"}</span>
          <div className="dots" aria-hidden="true">
            {snap.carryBits.pine > 0 ? <i className="pine" /> : null}
            {snap.carryBits.birch > 0 ? <i className="birch" /> : null}
            {snap.carryBits.cedar > 0 ? <i className="cedar" /> : null}
          </div>
        </div>
        {snap.near ? (
          <button className="act-btn" type="button" onClick={() => bus.push({ t: "interact" })}>
            {snap.near.label}
            <small>{snap.near.sub}</small>
          </button>
        ) : (
          <span />
        )}
      </div>
      <div className="keys">WASD — ходить · клик по дереву · E — действие</div>
    </>
  );
}

function Joystick() {
  const ref = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  const move = (clientX: number, clientY: number) => {
    const node = ref.current;
    if (!node) return;
    const rect = node.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const max = rect.width / 2;
    const len = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(len, max);
    dx = (dx / len) * clamped;
    dy = (dy / len) * clamped;
    bus.moveX = dx / max;
    bus.moveY = -dy / max;
    setKnob({ x: dx, y: dy });
  };

  const end = () => {
    bus.moveX = 0;
    bus.moveY = 0;
    setKnob({ x: 0, y: 0 });
  };

  return (
    <div
      className="joy"
      ref={ref}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        audio.unlock();
        move(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) move(e.clientX, e.clientY);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div className="joy-knob" style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }} />
    </div>
  );
}

function Sheet({ snap }: { snap: Snap }) {
  const [armed, setArmed] = useState(false);
  const title =
    snap.panel === "upgrade" ? "Апгрейды" : snap.panel === "map" ? "Делянки" : snap.panel === "quest" ? "Задания" : "Меню";
  return (
    <div className="sheet-back" onClick={() => bus.push({ t: "panel", panel: "none" })}>
      <div
        className="sheet"
        role="dialog"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sheet-head">
          <h2>{title}</h2>
          <button className="icon-btn" type="button" aria-label="Закрыть" onClick={() => bus.push({ t: "panel", panel: "none" })}>
            <X />
          </button>
        </div>
        {snap.panel === "upgrade"
          ? snap.upgrades.map((row) => {
              const Icon = ICONS[row.id];
              return (
                <div className="row" key={row.id}>
                  <div className="row-ico">
                    <Icon />
                  </div>
                  <div className="row-copy">
                    <strong>{row.title}</strong>
                    <p>{row.effect}</p>
                    <div className="pips" aria-hidden="true">
                      {Array.from({ length: row.max }, (_, i) => (
                        <i key={i} className={i < row.level ? "on" : ""} />
                      ))}
                    </div>
                  </div>
                  <button
                    className="price"
                    type="button"
                    disabled={row.cost == null}
                    onClick={() => bus.push({ t: "buy", id: row.id })}
                  >
                    {row.cost == null ? "Макс." : `${fmt(row.cost)} ₽`}
                  </button>
                </div>
              );
            })
          : null}
        {snap.panel === "map" ? (
          <>
            {snap.zones.map((zone) => (
              <div className="zone-card" key={zone.id}>
                <div className={`zone-swatch ${zone.open ? zone.id : "locked"}`}>
                  <TreePine />
                </div>
                <div className="zone-copy">
                  <strong>{zone.title}</strong>
                  <p>
                    {zone.blurb}
                    {zone.open ? ` · срублено ${zone.chops}` : ""}
                    {zone.stock > 0 ? ` · склад ${zone.stock}` : ""}
                  </p>
                </div>
                {zone.open ? (
                  <button className="price" type="button" onClick={() => bus.push({ t: "travel", zone: zone.id })}>
                    Перейти
                  </button>
                ) : (
                  <button
                    className="price"
                    type="button"
                    onClick={() => {
                      if (zone.id === "birch" || zone.id === "cedar") bus.push({ t: "unlock", zone: zone.id });
                    }}
                  >
                    {fmt(zone.cost)} ₽
                  </button>
                )}
              </div>
            ))}
            <div className="btn-row sheet-gap">
              <button className="ghost" type="button" onClick={() => bus.push({ t: "travel", zone: "camp" })}>
                Вернуться на базу
              </button>
            </div>
          </>
        ) : null}
        {snap.panel === "quest"
          ? snap.quests.map((quest) => {
              const qpct = Math.max(0, Math.min(100, (quest.cur / Math.max(1, quest.goal)) * 100));
              return (
                <div className="row" key={quest.id}>
                  <div className="row-copy">
                    <strong>{quest.done ? "Готово · " : ""}{quest.title}</strong>
                    <p>
                      {quest.detail} · награда {fmt(quest.reward)} ₽
                    </p>
                    <div className="bar">
                      <i style={{ width: `${qpct}%` }} />
                    </div>
                  </div>
                  <span className="count">
                    {quest.cur}/{quest.goal}
                  </span>
                </div>
              );
            })
          : null}
        {snap.panel === "menu" ? (
          <div className="menu-block">
            <p className="stat-line">
              Срублено {snap.chops} деревьев. Заработано {fmt(snap.earned)} ₽. В бригаде {snap.workers}.
              Прогресс хранится на этом устройстве.
            </p>
            <button className="menu-btn" type="button" onClick={() => bus.push({ t: "sound", on: !snap.sound })}>
              {snap.sound ? <Volume2 /> : <VolumeX />} {snap.sound ? "Звук включён" : "Звук выключен"}
            </button>
            <button className="menu-btn" type="button" onClick={() => bus.push({ t: "shake", on: !snap.shake })}>
              {snap.shake ? "Тряска камеры включена" : "Тряска камеры выключена"}
            </button>
            <button
              className="menu-btn"
              type="button"
              onClick={() => {
                if (!armed) {
                  setArmed(true);
                  return;
                }
                bus.push({ t: "reset" });
              }}
            >
              {armed ? "Точно сбросить прогресс" : "Сбросить прогресс"}
            </button>
          </div>
        ) : null}
      </div>
    </div>
  );
}
