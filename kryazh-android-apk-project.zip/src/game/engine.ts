import * as THREE from "three";
import {
  LIMITS,
  QUESTS,
  SPECIES_META,
  ZONE_COST,
  axeCost,
  axeDamage,
  bootsCost,
  carryCap,
  carryCount,
  defaultSave,
  fmt,
  levelProgress,
  logValue,
  millBonus,
  millCost,
  moveSpeed,
  packCost,
  stockCount,
  swingTime,
  tractorCap,
  tractorCost,
  tractorSpeed,
  workerCarryCap,
  workerCost,
  type Save,
  type Species,
} from "./balance";
import { audio } from "./audio";
import { clearSave, loadSave, writeSave } from "./save";
import { bus, type NearPrompt, type Panel, type Snap, type UpgradeId } from "./store";
import { HALF, heightAt } from "./terrain";
import { makeTextures } from "./textures";

const CAM_XZ = 13;
const CAM_Y = 19;
const FWD_X = -Math.SQRT1_2;
const FWD_Z = -Math.SQRT1_2;
const RIGHT_X = Math.SQRT1_2;
const RIGHT_Z = -Math.SQRT1_2;

const SPAWN = { x: 1.5, z: 11.6 };
const SELL = { x: 8.4, z: 7.6 };
const MILL = { x: -7.4, z: 4.2 };
const ASSIST = { x: 0.2, z: 1.6 };
const PARK = { x: 9.2, z: 2.6 };

const ZONES: {
  id: Species;
  title: string;
  blurb: string;
  cx: number;
  cz: number;
  radius: number;
  count: number;
  cost: number;
}[] = [
  { id: "pine", title: "Сосновый выдел", blurb: "Мягкая древесина, быстрые деньги", cx: -30, cz: -12, radius: 24, count: 30, cost: 0 },
  { id: "birch", title: "Берёзовая роща", blurb: "Светлый кряж по цене выше", cx: 32, cz: -8, radius: 21, count: 24, cost: ZONE_COST.birch },
  { id: "cedar", title: "Кедровый склон", blurb: "Плотный лес, крупный чек", cx: 1, cz: -50, radius: 20, count: 22, cost: ZONE_COST.cedar },
];

type Tree = {
  id: number;
  species: Species;
  x: number;
  z: number;
  y: number;
  scale: number;
  yaw: number;
  hp: number;
  maxHp: number;
  fall: number;
  falling: boolean;
  dead: boolean;
  regrow: number;
  grow: number;
  shake: number;
  flash: number;
  reserved: number;
  tint: number;
};

type Rig = {
  root: THREE.Group;
  bob: THREE.Group;
  torso: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  logs: THREE.Mesh[];
  phase: number;
};

type Worker = {
  id: number;
  x: number;
  z: number;
  yaw: number;
  state: "toTree" | "chop" | "toSell";
  tree: number;
  carry: number;
  species: Species;
  chopCd: number;
  chopAnim: number;
  spawn: number;
  stuck: number;
};

type Drop = {
  alive: boolean;
  x: number;
  y: number;
  z: number;
  vy: number;
  species: Species;
  age: number;
};

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
    };
  }
}

const SPECIES_LIST: Species[] = ["pine", "birch", "cedar"];

function damp(a: number, b: number, k: number, dt: number) {
  const diff = Math.atan2(Math.sin(b - a), Math.cos(b - a));
  return a + diff * (1 - Math.exp(-k * dt));
}

function easeIn(t: number) {
  return t * t;
}

function easeOutBack(t: number) {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function zoneOpen(species: Species, save: Save) {
  if (species === "pine") return true;
  return save.zones[species];
}

export function mount(canvas: HTMLCanvasElement) {
  let dead = false;
  try {
    const dispose = start(canvas, () => dead);
    return () => {
      dead = true;
      dispose();
    };
  } catch (err) {
    bus.publish({
      ...bus.getSnapshot(),
      bootError: err instanceof Error ? err.message : "Не удалось запустить смену",
      hasSave: false,
    });
    return () => {
      dead = true;
    };
  }
}

function start(canvas: HTMLCanvasElement, isDead: () => boolean) {
  const disposables: { dispose: () => void }[] = [];
  const track = <T extends { dispose: () => void }>(item: T) => {
    disposables.push(item);
    return item;
  };

  let renderer: THREE.WebGLRenderer;
  try {
    renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
  } catch (err) {
    bus.publish({
      ...bus.getSnapshot(),
      bootError: err instanceof Error ? err.message : "WebGL недоступен",
      hasSave: loadSave() !== null,
    });
    return () => {};
  }

  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
  renderer.setClearColor(0x9eb6c8, 1);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0xb7c6b0, 0.0115);
  const camera = new THREE.PerspectiveCamera(56, 1, 0.25, 420);
  scene.add(camera);

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let save = defaultSave();
  if (reduceMotion) save.shake = false;
  let phase: "title" | "play" = "title";
  let panel: Panel = "none";
  let hasSaveFlag = loadSave() !== null;

  const tex = makeTextures();
  for (const t of Object.values(tex)) track(t);

  const keys = new Set<string>();
  const persist = { dirty: false, acc: 0 };

  const player = {
    x: SPAWN.x,
    z: SPAWN.z,
    yaw: Math.atan2(-FWD_X, -FWD_Z),
    speed: 0,
    chopCd: 0,
    chopAnim: 0,
    phase: 0,
  };
  let dest: { x: number; z: number } | null = null;
  let focus = -1;
  let hitstop = 0;
  let trauma = 0;
  let flashAmt = 0;
  let shownLevel = 1;
  let near: NearPrompt | null = null;
  let toast = "";
  let toastId = 0;
  let toastT = 0;
  const toastQ: string[] = [];
  let dirty = true;
  let pubAcc = 0;
  let chirpAcc = 0;
  const cargo: Record<Species, number> = { pine: 0, birch: 0, cedar: 0 };
  const tractor = {
    x: PARK.x,
    z: PARK.z,
    yaw: Math.PI,
    leg: "park" as "park" | "toDepot" | "toSell",
    tx: PARK.x,
    tz: PARK.z,
    wait: 0,
    roll: 0,
  };

  function pushToast(text: string) {
    toastQ.push(text);
    dirty = true;
  }

  function commit() {
    if (phase === "play") writeSave(save);
  }

  const trees: Tree[] = [];
  const rng = mulberry32(0x5eed);
  const occupied: { x: number; z: number }[] = [];
  const addTree = (species: Species, x: number, z: number, scale: number) => {
    const meta = SPECIES_META[species];
    const tree: Tree = {
      id: trees.length,
      species,
      x,
      z,
      y: heightAt(x, z),
      scale,
      yaw: rng() * Math.PI * 2,
      hp: meta.hp,
      maxHp: meta.hp,
      fall: 0,
      falling: false,
      dead: false,
      regrow: 0,
      grow: 1,
      shake: 0,
      flash: 0,
      reserved: -1,
      tint: 0.92 + rng() * 0.16,
    };
    trees.push(tree);
    occupied.push({ x, z });
  };

  for (const [dist, side, scale] of [
    [9.4, 0, 1.05],
    [12.2, 2.3, 0.92],
    [12.6, -2.5, 1.08],
    [16.4, 1.1, 1],
    [16.8, -3.3, 0.96],
    [20.5, 0.6, 1.12],
  ] as const) {
    addTree(
      "pine",
      SPAWN.x + FWD_X * dist + RIGHT_X * side,
      SPAWN.z + FWD_Z * dist + RIGHT_Z * side,
      scale,
    );
  }

  for (const zone of ZONES) {
    let placed = 0;
    let guard = 0;
    while (placed < zone.count && guard < 6000) {
      guard += 1;
      const ang = rng() * Math.PI * 2;
      const rad = Math.sqrt(rng()) * zone.radius;
      const x = zone.cx + Math.cos(ang) * rad;
      const z = zone.cz + Math.sin(ang) * rad;
      if (Math.hypot(x - SPAWN.x, z - SPAWN.z) < 8.4) continue;
      if (Math.hypot(x - SELL.x, z - SELL.z) < 4.2) continue;
      if (Math.hypot(x - MILL.x, z - MILL.z) < 4.6) continue;
      if (Math.hypot(x, z) < 6.5) continue;
      if (occupied.some((p) => (p.x - x) ** 2 + (p.z - z) ** 2 < 14.5)) continue;
      addTree(zone.id, x, z, 0.86 + rng() * 0.38);
      placed += 1;
    }
  }

  function revive() {
    for (const tree of trees) {
      tree.dead = false;
      tree.falling = false;
      tree.fall = 0;
      tree.hp = tree.maxHp;
      tree.grow = 1;
      tree.regrow = 0;
      tree.flash = 0;
      tree.shake = 0;
      tree.reserved = -1;
    }
    for (const drop of drops) drop.alive = false;
    cargo.pine = cargo.birch = cargo.cedar = 0;
  }

  const hemi = new THREE.HemisphereLight(0xd7e7ff, 0x6d8a4c, 0.85);
  scene.add(hemi);
  const ambient = new THREE.AmbientLight(0xfff4e4, 0.28);
  scene.add(ambient);
  const sun = new THREE.DirectionalLight(0xfff0d0, 2.8);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.near = 0.5;
  sun.shadow.camera.far = 96;
  sun.shadow.camera.left = -26;
  sun.shadow.camera.right = 26;
  sun.shadow.camera.top = 26;
  sun.shadow.camera.bottom = -26;
  sun.shadow.bias = -0.00035;
  sun.shadow.normalBias = 0.035;
  scene.add(sun, sun.target);
  const rim = new THREE.DirectionalLight(0xb7d4ff, 0.55);
  scene.add(rim);

  const sky = new THREE.Mesh(
    track(new THREE.SphereGeometry(320, 20, 14)),
    track(
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        vertexShader: `
          varying vec3 vP;
          void main() {
            vP = position;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          varying vec3 vP;
          void main() {
            vec3 n = normalize(vP);
            float h = n.y;
            vec3 hor = vec3(0.97, 0.82, 0.64);
            vec3 mid = vec3(0.55, 0.74, 0.90);
            vec3 top = vec3(0.28, 0.48, 0.78);
            vec3 col = mix(hor, mid, smoothstep(0.0, 0.22, h));
            col = mix(col, top, smoothstep(0.16, 0.75, h));
            float sunDot = pow(max(dot(n, normalize(vec3(0.55, 0.42, 0.32))), 0.0), 40.0);
            col += vec3(1.0, 0.86, 0.55) * sunDot;
            gl_FragColor = vec4(col, 1.0);
          }
        `,
      }),
    ),
  );
  scene.add(sky);

  const groundGeo = track(new THREE.PlaneGeometry(HALF * 2, HALF * 2, 70, 70));
  groundGeo.rotateX(-Math.PI / 2);
  const gp = groundGeo.attributes.position;
  if (!gp) throw new Error("ground");
  for (let i = 0; i < gp.count; i++) gp.setY(i, heightAt(gp.getX(i), gp.getZ(i)));
  groundGeo.computeVertexNormals();
  const ground = new THREE.Mesh(
    groundGeo,
    track(new THREE.MeshStandardMaterial({ map: tex.ground, roughness: 0.94, metalness: 0 })),
  );
  ground.receiveShadow = true;
  scene.add(ground);

  const barkMat = track(new THREE.MeshStandardMaterial({ map: tex.bark, roughness: 0.9, metalness: 0 }));
  const birchMat = track(new THREE.MeshStandardMaterial({ map: tex.birch, roughness: 0.78, metalness: 0 }));
  const leafMat = (color: number) =>
    track(new THREE.MeshStandardMaterial({ color, roughness: 0.86, metalness: 0 }));
  const pineLeaf = leafMat(0xffffff);
  const birchLeaf = leafMat(0xffffff);
  const cedarLeaf = leafMat(0xffffff);
  const stumpMat = track(new THREE.MeshStandardMaterial({ map: tex.bark, roughness: 0.95 }));

  function treeGeo(species: Species) {
    if (species === "birch") {
      const trunk = track(new THREE.CylinderGeometry(0.13, 0.2, 2.45, 7));
      trunk.translate(0, 1.22, 0);
      const a = track(new THREE.SphereGeometry(0.95, 10, 8));
      a.translate(0, 2.65, 0);
      const b = track(new THREE.SphereGeometry(0.68, 8, 7));
      b.translate(0.28, 3.25, 0.12);
      const stump = track(new THREE.CylinderGeometry(0.22, 0.26, 0.28, 7));
      stump.translate(0, 0.14, 0);
      return { trunk, a, b, stump, trunkMat: birchMat, leafMat: birchLeaf };
    }
    if (species === "cedar") {
      const trunk = track(new THREE.CylinderGeometry(0.2, 0.34, 2.7, 7));
      trunk.translate(0, 1.35, 0);
      const a = track(new THREE.ConeGeometry(1.45, 2.5, 8));
      a.translate(0, 2.7, 0);
      const b = track(new THREE.ConeGeometry(1.05, 1.9, 8));
      b.translate(0, 3.7, 0);
      const stump = track(new THREE.CylinderGeometry(0.34, 0.4, 0.3, 7));
      stump.translate(0, 0.15, 0);
      return { trunk, a, b, stump, trunkMat: barkMat, leafMat: cedarLeaf };
    }
    const trunk = track(new THREE.CylinderGeometry(0.15, 0.28, 2.25, 7));
    trunk.translate(0, 1.12, 0);
    const a = track(new THREE.ConeGeometry(1.22, 2.25, 8));
    a.translate(0, 2.35, 0);
    const b = track(new THREE.ConeGeometry(0.86, 1.7, 8));
    b.translate(0, 3.25, 0);
    const stump = track(new THREE.CylinderGeometry(0.28, 0.34, 0.26, 7));
    stump.translate(0, 0.13, 0);
    return { trunk, a, b, stump, trunkMat: barkMat, leafMat: pineLeaf };
  }

  const leafBase: Record<Species, THREE.Color> = {
    pine: new THREE.Color(0.22, 0.48, 0.26),
    birch: new THREE.Color(0.62, 0.74, 0.28),
    cedar: new THREE.Color(0.12, 0.32, 0.2),
  };
  const lists = new Map<THREE.Object3D, Tree[]>();
  const treeMeshes: THREE.InstancedMesh[] = [];
  const buckets: {
    species: Species;
    list: Tree[];
    trunk: THREE.InstancedMesh;
    leafA: THREE.InstancedMesh;
    leafB: THREE.InstancedMesh;
    stump: THREE.InstancedMesh;
  }[] = [];

  for (const species of SPECIES_LIST) {
    const list = trees.filter((t) => t.species === species);
    const geo = treeGeo(species);
    const count = Math.max(1, list.length);
    const trunk = new THREE.InstancedMesh(geo.trunk, geo.trunkMat, count);
    const leafA = new THREE.InstancedMesh(geo.a, geo.leafMat, count);
    const leafB = new THREE.InstancedMesh(geo.b, geo.leafMat, count);
    const stump = new THREE.InstancedMesh(geo.stump, stumpMat, count);
    for (const mesh of [trunk, leafA, leafB]) {
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      lists.set(mesh, list);
      treeMeshes.push(mesh);
      scene.add(mesh);
    }
    stump.receiveShadow = true;
    lists.set(stump, list);
    scene.add(stump);
    const white = new THREE.Color(1, 1, 1);
    for (let i = 0; i < count; i++) {
      trunk.setColorAt(i, white);
      leafA.setColorAt(i, leafBase[species]);
      leafB.setColorAt(i, leafBase[species]);
    }
    buckets.push({ species, list, trunk, leafA, leafB, stump });
  }

  const dummy = new THREE.Object3D();
  const tintColor = new THREE.Color();
  const flashColor = new THREE.Color();
  const WHITE = new THREE.Color(1, 1, 1);

  function writeTrees(time: number) {
    for (const bucket of buckets) {
      const { list, trunk, leafA, leafB, stump } = bucket;
      for (let i = 0; i < list.length; i++) {
        const tree = list[i];
        if (!tree) continue;
        const lean = tree.fall > 0 ? easeIn(Math.min(1, tree.fall)) * 1.28 : 0;
        const shrink =
          tree.dead && !tree.falling && tree.regrow < 1.2 ? Math.max(0.001, tree.regrow / 1.2) : 1;
        const grow = !tree.dead ? Math.max(0.001, easeOutBack(Math.min(1, tree.grow))) : 1;
        const sc = tree.scale * (tree.dead || tree.falling ? shrink : grow);
        const wind = tree.dead ? 0 : Math.sin(time * 1.25 + tree.id * 0.7) * 0.04;
        const shake = Math.sin(time * 36 + tree.id) * tree.shake;
        dummy.position.set(tree.x, tree.y, tree.z);
        dummy.rotation.order = "YXZ";
        dummy.rotation.set(lean, tree.yaw + wind * 0.3, shake);
        dummy.scale.setScalar(Math.max(0.001, sc));
        dummy.updateMatrix();
        trunk.setMatrixAt(i, dummy.matrix);
        dummy.rotation.set(lean + wind * 1.6, tree.yaw, shake);
        dummy.updateMatrix();
        leafA.setMatrixAt(i, dummy.matrix);
        dummy.rotation.y += 0.5;
        dummy.rotation.x += wind;
        dummy.updateMatrix();
        leafB.setMatrixAt(i, dummy.matrix);
        const showStump = tree.dead || tree.falling ? tree.scale : 0.0001;
        dummy.position.set(tree.x, tree.y, tree.z);
        dummy.rotation.set(0, tree.yaw, 0);
        dummy.scale.setScalar(showStump);
        dummy.updateMatrix();
        stump.setMatrixAt(i, dummy.matrix);
        tintColor.setRGB(tree.tint + tree.flash * 0.8, tree.tint + tree.flash * 0.65, tree.tint + tree.flash * 0.4);
        trunk.setColorAt(i, tintColor);
        flashColor.copy(leafBase[tree.species]).lerp(WHITE, tree.flash * 0.7);
        flashColor.multiplyScalar(tree.tint);
        leafA.setColorAt(i, flashColor);
        leafB.setColorAt(i, flashColor);
      }
      trunk.instanceMatrix.needsUpdate = true;
      leafA.instanceMatrix.needsUpdate = true;
      leafB.instanceMatrix.needsUpdate = true;
      stump.instanceMatrix.needsUpdate = true;
      if (trunk.instanceColor) trunk.instanceColor.needsUpdate = true;
      if (leafA.instanceColor) leafA.instanceColor.needsUpdate = true;
      if (leafB.instanceColor) leafB.instanceColor.needsUpdate = true;
    }
  }

  for (const bucket of buckets) {
    writeTrees(0);
    for (const mesh of [bucket.trunk, bucket.leafA, bucket.leafB, bucket.stump]) {
      mesh.computeBoundingSphere();
    }
  }

  const woodMat = track(new THREE.MeshStandardMaterial({ map: tex.plank, roughness: 0.82 }));
  const darkMat = track(new THREE.MeshStandardMaterial({ color: 0x2a3138, roughness: 0.6, metalness: 0.2 }));
  const blueMat = track(new THREE.MeshStandardMaterial({ color: 0x1a63c8, roughness: 0.42, metalness: 0.18 }));
  const metalMat = track(new THREE.MeshStandardMaterial({ color: 0xc5ccd2, roughness: 0.32, metalness: 0.7 }));
  const skinMat = track(new THREE.MeshStandardMaterial({ color: 0xd7a67a, roughness: 0.72 }));
  const pantsMat = track(new THREE.MeshStandardMaterial({ color: 0x24385f, roughness: 0.8 }));
  const bootMat = track(new THREE.MeshStandardMaterial({ color: 0x241c16, roughness: 0.78 }));
  const plaidMat = track(new THREE.MeshStandardMaterial({ map: tex.plaid, roughness: 0.75 }));

  function makePerson(shirt: THREE.Material, hatColor: number, withAxe: boolean): Rig {
    const root = new THREE.Group();
    const bob = new THREE.Group();
    root.add(bob);
    const hatMat = track(new THREE.MeshStandardMaterial({ color: hatColor, roughness: 0.7 }));
    const legGeo = track(new THREE.BoxGeometry(0.16, 0.5, 0.18));
    const bootGeo = track(new THREE.BoxGeometry(0.18, 0.12, 0.28));
    const armGeo = track(new THREE.BoxGeometry(0.12, 0.44, 0.12));
    const mkLeg = (x: number) => {
      const pivot = new THREE.Group();
      pivot.position.set(x, 0.9, 0);
      const leg = new THREE.Mesh(legGeo, pantsMat);
      leg.position.y = -0.24;
      leg.castShadow = true;
      const boot = new THREE.Mesh(bootGeo, bootMat);
      boot.position.set(0, -0.5, -0.04);
      boot.castShadow = true;
      pivot.add(leg, boot);
      return pivot;
    };
    const legL = mkLeg(-0.12);
    const legR = mkLeg(0.12);
    const torso = new THREE.Group();
    torso.position.y = 0.9;
    const chest = new THREE.Mesh(track(new THREE.BoxGeometry(0.46, 0.48, 0.26)), shirt);
    chest.position.y = 0.26;
    chest.castShadow = true;
    const head = new THREE.Mesh(track(new THREE.SphereGeometry(0.155, 12, 10)), skinMat);
    head.position.y = 0.64;
    head.castShadow = true;
    const eyeGeo = track(new THREE.SphereGeometry(0.022, 6, 6));
    const eyeMat = track(new THREE.MeshStandardMaterial({ color: 0x1c1612 }));
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    eyeL.position.set(-0.052, 0.66, -0.13);
    eyeR.position.set(0.052, 0.66, -0.13);
    const hat = new THREE.Mesh(track(new THREE.CylinderGeometry(0.145, 0.155, 0.12, 10)), hatMat);
    hat.position.y = 0.78;
    const brim = new THREE.Mesh(track(new THREE.BoxGeometry(0.3, 0.035, 0.18)), hatMat);
    brim.position.set(0, 0.72, -0.1);
    const armL = new THREE.Group();
    const armR = new THREE.Group();
    armL.position.set(-0.32, 0.42, 0);
    armR.position.set(0.32, 0.42, 0);
    const aL = new THREE.Mesh(armGeo, shirt);
    const aR = new THREE.Mesh(armGeo, shirt);
    aL.position.y = -0.2;
    aR.position.y = -0.2;
    aL.castShadow = true;
    aR.castShadow = true;
    armL.add(aL);
    armR.add(aR);
    if (withAxe) {
      const axe = new THREE.Group();
      axe.position.set(0.02, -0.42, -0.02);
      const handle = new THREE.Mesh(track(new THREE.CylinderGeometry(0.028, 0.034, 0.62, 6)), woodMat);
      handle.position.y = -0.16;
      const head = new THREE.Mesh(track(new THREE.BoxGeometry(0.24, 0.14, 0.05)), metalMat);
      head.position.set(0.08, -0.42, 0);
      axe.add(handle, head);
      armR.add(axe);
    }
    torso.add(chest, head, eyeL, eyeR, hat, brim, armL, armR);
    const logs: THREE.Mesh[] = [];
    const logGeo = track(new THREE.CylinderGeometry(0.065, 0.075, 0.4, 6));
    logGeo.rotateZ(Math.PI / 2);
    for (let i = 0; i < 3; i++) {
      const log = new THREE.Mesh(logGeo, woodMat);
      log.position.set(0, 0.22 + i * 0.075, 0.18);
      log.visible = false;
      log.castShadow = true;
      torso.add(log);
      logs.push(log);
    }
    bob.add(torso, legL, legR);
    const blob = new THREE.Mesh(
      track(new THREE.CircleGeometry(0.46, 14)),
      track(new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.22, depthWrite: false })),
    );
    blob.rotation.x = -Math.PI / 2;
    blob.position.y = 0.04;
    root.add(blob);
    root.scale.setScalar(1.14);
    scene.add(root);
    return { root, bob, torso, armL, armR, legL, legR, logs, phase: 0 };
  }

  function pose(rig: Rig, dt: number, moving: boolean, chop: number, carryN: number) {
    rig.phase += dt * (moving ? 11.5 : 0);
    const sw = Math.sin(rig.phase);
    const amp = moving ? 0.78 : 0;
    rig.legL.rotation.x = sw * amp;
    rig.legR.rotation.x = -sw * amp;
    rig.bob.position.y = moving ? Math.abs(sw) * 0.05 : Math.sin(performance.now() / 600) * 0.01;
    if (chop > 0 && chop < 1) {
      let ax: number;
      if (chop < 0.34) ax = -0.25 - (chop / 0.34) * 1.85;
      else if (chop < 0.5) ax = -2.1 + ((chop - 0.34) / 0.16) * 2.7;
      else ax = 0.45 * (1 - (chop - 0.5) / 0.5);
      rig.armR.rotation.x = ax;
      rig.armL.rotation.x = -0.35;
      rig.torso.rotation.y = chop < 0.55 ? -0.5 * Math.sin((chop / 0.55) * Math.PI) : 0;
    } else {
      rig.armL.rotation.x = sw * amp * 0.55;
      rig.armR.rotation.x = -sw * amp * 0.5;
      rig.torso.rotation.y = sw * 0.06 * (moving ? 1 : 0);
    }
    rig.logs.forEach((log, i) => {
      log.visible = carryN > i * 2;
    });
  }

  const hero = makePerson(plaidMat, 0x8d5a32, true);
  const foreman = makePerson(
    track(new THREE.MeshStandardMaterial({ color: 0x314e3a, roughness: 0.75 })),
    0x6b4a2c,
    false,
  );
  const workerRigs = [0x2f6b4f, 0xd7a441, 0x34507a, 0xb5523a, 0x6b4c8a].map((color) =>
    makePerson(track(new THREE.MeshStandardMaterial({ color, roughness: 0.75 })), 0x3d342c, true),
  );
  const workers: Worker[] = workerRigs.map((_, id) => ({
    id,
    x: ASSIST.x + Math.cos(id) * 1.4,
    z: ASSIST.z + 1.2 + id * 0.15,
    yaw: Math.PI,
    state: "toTree" as const,
    tree: -1,
    carry: 0,
    species: "pine" as Species,
    chopCd: 0,
    chopAnim: 0,
    spawn: 0,
    stuck: 0,
  }));
  workerRigs.forEach((rig) => {
    rig.root.visible = false;
  });

  function placeRig(rig: Rig, x: number, z: number, yaw: number) {
    rig.root.position.set(x, heightAt(x, z), z);
    rig.root.rotation.y = yaw;
  }

  const blocks = [
    { x: MILL.x, z: MILL.z, r: 2.55 },
    { x: SELL.x, z: SELL.z, r: 2.15 },
  ];

  function constrain(x: number, z: number, rad: number) {
    for (let pass = 0; pass < 2; pass++) {
      const lim = 68;
      const outer = Math.hypot(x, z);
      if (outer > lim) {
        x = (x / outer) * lim;
        z = (z / outer) * lim;
      }
      for (const tree of trees) {
        if (tree.dead && tree.fall > 0.8) continue;
        const dx = x - tree.x;
        const dz = z - tree.z;
        const min = 0.72 * tree.scale + rad;
        const dd = dx * dx + dz * dz;
        if (dd < min * min && dd > 1e-6) {
          const dist = Math.sqrt(dd);
          x = tree.x + (dx / dist) * min;
          z = tree.z + (dz / dist) * min;
        }
      }
      for (const block of blocks) {
        const dx = x - block.x;
        const dz = z - block.z;
        const min = block.r + rad;
        const dd = dx * dx + dz * dz;
        if (dd < min * min && dd > 1e-6) {
          const dist = Math.sqrt(dd);
          x = block.x + (dx / dist) * min;
          z = block.z + (dz / dist) * min;
        }
      }
      if (save.tractor > 0) {
        const dx = x - tractor.x;
        const dz = z - tractor.z;
        const min = 1.35 + rad;
        const dd = dx * dx + dz * dz;
        if (dd < min * min && dd > 1e-6) {
          const dist = Math.sqrt(dd);
          x = tractor.x + (dx / dist) * min;
          z = tractor.z + (dz / dist) * min;
        }
      }
      for (const zone of ZONES) {
        if (zone.cost === 0 || zoneOpen(zone.id, save)) continue;
        const dx = x - zone.cx;
        const dz = z - zone.cz;
        const dist = Math.hypot(dx, dz) || 0.0001;
        const min = zone.radius * 0.96 + rad;
        if (dist < min) {
          x = zone.cx + (dx / dist) * min;
          z = zone.cz + (dz / dist) * min;
        }
      }
    }
    return { x, z };
  }

  const MAX_P = 360;
  const pAlive = new Uint8Array(MAX_P);
  const pPos = new Float32Array(MAX_P * 3);
  const pVel = new Float32Array(MAX_P * 3);
  const pLife = new Float32Array(MAX_P);
  const pMax = new Float32Array(MAX_P);
  const pCol = new Float32Array(MAX_P * 3);
  const pGrav = new Float32Array(MAX_P);
  let pCursor = 0;
  const pGeo = track(new THREE.BufferGeometry());
  const pPosAttr = new THREE.BufferAttribute(pPos, 3);
  const pColAttr = new THREE.BufferAttribute(pCol, 3);
  pGeo.setAttribute("position", pPosAttr);
  pGeo.setAttribute("color", pColAttr);
  const points = new THREE.Points(
    pGeo,
    track(
      new THREE.PointsMaterial({
        size: 0.16,
        vertexColors: true,
        map: tex.soft,
        transparent: true,
        depthWrite: false,
        sizeAttenuation: true,
      }),
    ),
  );
  points.frustumCulled = false;
  scene.add(points);

  function burst(x: number, y: number, z: number, n: number, color: THREE.Color, speed: number, grav: number, life: number) {
    for (let k = 0; k < n; k++) {
      let idx = -1;
      for (let j = 0; j < MAX_P; j++) {
        const i = (pCursor + j) % MAX_P;
        if (!pAlive[i]) {
          idx = i;
          pCursor = (i + 1) % MAX_P;
          break;
        }
      }
      if (idx < 0) return;
      pAlive[idx] = 1;
      pPos[idx * 3] = x;
      pPos[idx * 3 + 1] = y;
      pPos[idx * 3 + 2] = z;
      const ang = Math.random() * Math.PI * 2;
      const sp = speed * (0.4 + Math.random());
      pVel[idx * 3] = Math.cos(ang) * sp;
      pVel[idx * 3 + 1] = speed * (0.4 + Math.random());
      pVel[idx * 3 + 2] = Math.sin(ang) * sp;
      pLife[idx] = life * (0.7 + Math.random() * 0.5);
      pMax[idx] = pLife[idx];
      pCol[idx * 3] = color.r;
      pCol[idx * 3 + 1] = color.g;
      pCol[idx * 3 + 2] = color.b;
      pGrav[idx] = grav;
    }
  }

  const chip = new THREE.Color(0.62, 0.42, 0.22);
  const leafP = new THREE.Color(0.35, 0.62, 0.28);
  const gold = new THREE.Color(0.95, 0.78, 0.28);
  const smoke = new THREE.Color(0.75, 0.75, 0.72);

  const drops: Drop[] = Array.from({ length: 40 }, () => ({
    alive: false,
    x: 0,
    y: 0,
    z: 0,
    vy: 0,
    species: "pine" as Species,
    age: 0,
  }));
  const logGeo = track(new THREE.CylinderGeometry(0.1, 0.12, 0.55, 6));
  logGeo.rotateZ(Math.PI / 2);
  const logMesh = new THREE.InstancedMesh(logGeo, woodMat, drops.length);
  logMesh.castShadow = true;
  scene.add(logMesh);
  const logColors: Record<Species, THREE.Color> = {
    pine: new THREE.Color(0.72, 0.5, 0.3),
    birch: new THREE.Color(0.86, 0.82, 0.74),
    cedar: new THREE.Color(0.45, 0.3, 0.2),
  };

  function spawnDrop(species: Species, x: number, z: number) {
    const slot = drops.find((d) => !d.alive);
    if (!slot) {
      save.stock[species] += 1;
      return;
    }
    slot.alive = true;
    slot.species = species;
    slot.x = x + (Math.random() - 0.5) * 0.9;
    slot.z = z + (Math.random() - 0.5) * 0.9;
    slot.y = 1.3;
    slot.vy = 2.4 + Math.random() * 1.4;
    slot.age = 0;
  }

  function giveWood(species: Species, n: number, who: "player" | number, x: number, z: number) {
    let left = n;
    if (who === "player") {
      const room = carryCap(save.pack) - carryCount(save.carry);
      const take = Math.max(0, Math.min(room, left));
      save.carry[species] += take;
      left -= take;
    } else {
      const worker = workers[who];
      if (worker && (worker.carry === 0 || worker.species === species)) {
        const room = workerCarryCap() - worker.carry;
        const take = Math.max(0, Math.min(room, left));
        worker.species = species;
        worker.carry += take;
        left -= take;
      }
    }
    for (let i = 0; i < left; i++) spawnDrop(species, x, z);
  }

  function payoutBag(bag: Record<Species, number>) {
    let sum = 0;
    for (const species of SPECIES_LIST) {
      sum += bag[species] * logValue(species, save.sawmill);
      bag[species] = 0;
    }
    if (sum <= 0) return 0;
    const money = Math.round(sum);
    save.money += money;
    save.earned += money;
    save.trips += 1;
    return money;
  }

  function checkQuests() {
    const lp = levelProgress(save.chops);
    if (lp.level > shownLevel) {
      shownLevel = lp.level;
      if (save.chops > 0) {
        pushToast(`Уровень ${lp.level}`);
        audio.fanfare();
      }
    }
    for (const quest of QUESTS) {
      if (save.claimed.includes(quest.id)) continue;
      if (quest.cur(save) < quest.goal) continue;
      save.claimed.push(quest.id);
      save.money += quest.reward;
      pushToast(`${quest.title}  +${fmt(quest.reward)} ₽`);
      audio.fanfare();
      dirty = true;
    }
  }

  function fell(tree: Tree, who: "player" | number) {
    tree.dead = true;
    tree.falling = true;
    tree.fall = 0.02;
    tree.hp = 0;
    tree.reserved = -1;
    save.chops += 1;
    save.chopsBy[tree.species] += 1;
    giveWood(tree.species, SPECIES_META[tree.species].yield, who, tree.x, tree.z);
    audio.fall();
    trauma = Math.min(1, trauma + (save.shake ? 0.38 : 0));
    flashAmt = Math.min(0.35, flashAmt + 0.18);
    hitstop = 0.035;
    burst(tree.x, tree.y + 1.6, tree.z, 16, chip, 3.2, 9, 0.55);
    burst(tree.x, tree.y + 2.4, tree.z, 12, leafP, 2.4, 2.5, 0.8);
    checkQuests();
    persist.dirty = true;
    dirty = true;
  }

  function costOf(id: UpgradeId): number | null {
    if (id === "axe") return save.axe >= LIMITS.axe ? null : axeCost(save.axe);
    if (id === "boots") return save.boots >= LIMITS.boots ? null : bootsCost(save.boots);
    if (id === "pack") return save.pack >= LIMITS.pack ? null : packCost(save.pack);
    if (id === "workers") return save.workers >= LIMITS.workers ? null : workerCost(save.workers);
    if (id === "tractor") return save.tractor >= LIMITS.tractor ? null : tractorCost(save.tractor);
    return save.sawmill >= LIMITS.sawmill ? null : millCost(save.sawmill);
  }

  function tryBuy(id: UpgradeId) {
    if (phase !== "play") return;
    const cost = costOf(id);
    if (cost == null) return;
    if (save.money < cost) {
      audio.deny();
      pushToast("Не хватает денег");
      return;
    }
    save.money -= cost;
    if (id === "axe") save.axe += 1;
    if (id === "boots") save.boots += 1;
    if (id === "pack") save.pack += 1;
    if (id === "workers") {
      save.workers += 1;
      const hired = workers[save.workers - 1];
      if (hired) {
        hired.spawn = 0.01;
        hired.x = ASSIST.x + hired.id * 0.4;
        hired.z = ASSIST.z + 0.8;
      }
      pushToast("Новый лесоруб вышел на смену");
    }
    if (id === "tractor") {
      save.tractor += 1;
      if (save.tractor === 1) pushToast("Трактор выехал за брёвнами");
    }
    if (id === "sawmill") save.sawmill += 1;
    audio.coin();
    checkQuests();
    commit();
    dirty = true;
  }

  function tryUnlock(zone: "birch" | "cedar") {
    if (phase !== "play" || save.zones[zone]) return;
    const cost = ZONE_COST[zone];
    if (save.money < cost) {
      audio.deny();
      pushToast("Не хватает денег");
      return;
    }
    save.money -= cost;
    save.zones[zone] = true;
    audio.fanfare();
    pushToast(zone === "birch" ? "Берёзовая роща открыта" : "Кедровый склон открыт");
    trauma = Math.min(1, trauma + 0.45);
    checkQuests();
    commit();
    dirty = true;
  }

  function pullStock() {
    let room = carryCap(save.pack) - carryCount(save.carry);
    if (room <= 0 || stockCount(save.stock) <= 0) {
      if (room <= 0) pushToast("Рюкзак полный");
      return;
    }
    for (const species of ["cedar", "birch", "pine"] as const) {
      while (room > 0 && save.stock[species] > 0) {
        save.stock[species] -= 1;
        save.carry[species] += 1;
        room -= 1;
      }
    }
    audio.coin();
    dirty = true;
  }

  function travel(zone: Species | "camp") {
    if (phase !== "play") return;
    if (zone === "camp") {
      player.x = SPAWN.x;
      player.z = SPAWN.z;
    } else if (!zoneOpen(zone, save)) {
      pushToast("Зона ещё закрыта");
      return;
    } else {
      const spot = ZONES.find((z) => z.id === zone);
      if (!spot) return;
      const len = Math.hypot(spot.cx, spot.cz) || 1;
      player.x = spot.cx - (spot.cx / len) * spot.radius * 0.55;
      player.z = spot.cz - (spot.cz / len) * spot.radius * 0.55;
    }
    dest = null;
    panel = "none";
    dirty = true;
  }

  function applyStart(fresh: boolean) {
    if (fresh) {
      save = defaultSave();
      if (reduceMotion) save.shake = false;
      clearSave();
      revive();
      for (const worker of workers) {
        worker.carry = 0;
        worker.tree = -1;
        worker.spawn = 0;
        worker.state = "toTree";
      }
      shownLevel = 1;
    } else {
      save = loadSave() ?? defaultSave();
      revive();
      shownLevel = levelProgress(save.chops).level;
      workers.forEach((worker, i) => {
        worker.spawn = i < save.workers ? 1 : 0;
        worker.carry = 0;
        worker.tree = -1;
      });
    }
    cargo.pine = cargo.birch = cargo.cedar = 0;
    player.x = SPAWN.x;
    player.z = SPAWN.z;
    player.yaw = Math.atan2(-FWD_X, -FWD_Z);
    phase = "play";
    panel = "none";
    hasSaveFlag = true;
    audio.setMuted(!save.sound);
    audio.startAmbience();
    pushToast(fresh ? "Подойди к сосне — топор сам начнёт рубить" : "С возвращением на делянку");
    commit();
    dirty = true;
  }

  function resetAll() {
    save = defaultSave();
    if (reduceMotion) save.shake = false;
    clearSave();
    revive();
    phase = "title";
    panel = "none";
    hasSaveFlag = false;
    player.x = SPAWN.x;
    player.z = SPAWN.z;
    toastQ.length = 0;
    toast = "";
    shownLevel = 1;
    for (const worker of workers) worker.spawn = 0;
    audio.stopAmbience();
    dirty = true;
  }

  function handle(cmd: (typeof bus.cmds)[number]) {
    if (cmd.t === "start") applyStart(cmd.fresh);
    else if (cmd.t === "panel") {
      panel = cmd.panel;
      if (panel !== "none") {
        bus.moveX = 0;
        bus.moveY = 0;
        dest = null;
      }
      dirty = true;
    } else if (cmd.t === "buy") tryBuy(cmd.id);
    else if (cmd.t === "unlock") tryUnlock(cmd.zone);
    else if (cmd.t === "travel") travel(cmd.zone);
    else if (cmd.t === "sound") {
      save.sound = cmd.on;
      audio.setMuted(!cmd.on);
      if (cmd.on) audio.startAmbience();
      commit();
      dirty = true;
    } else if (cmd.t === "shake") {
      save.shake = cmd.on;
      commit();
      dirty = true;
    } else if (cmd.t === "reset") resetAll();
    else if (cmd.t === "interact" && near) {
      if (near.kind === "mill") pullStock();
      if (near.kind === "hire") tryBuy("workers");
      if (near.kind === "birch") tryUnlock("birch");
      if (near.kind === "cedar") tryUnlock("cedar");
      if (near.kind === "tractor") tryBuy("tractor");
    }
  }

  const labelPool = Array.from({ length: 8 }, () => {
    const c = document.createElement("canvas");
    c.width = 256;
    c.height = 80;
    const ctx2 = c.getContext("2d");
    if (!ctx2) throw new Error("label");
    const map = track(new THREE.CanvasTexture(c));
    map.colorSpace = THREE.SRGBColorSpace;
    const mat = track(new THREE.SpriteMaterial({ map, transparent: true, depthWrite: false }));
    const sprite = new THREE.Sprite(mat);
    sprite.visible = false;
    sprite.scale.set(2.4, 0.75, 1);
    scene.add(sprite);
    return { sprite, ctx: ctx2, map, life: 0, x: 0, y: 0, z: 0 };
  });

  function popText(text: string, x: number, y: number, z: number) {
    const slot = labelPool.find((l) => l.life <= 0) ?? labelPool[0];
    if (!slot) return;
    slot.ctx.clearRect(0, 0, 256, 80);
    slot.ctx.font = "700 42px Liberation Sans, sans-serif";
    slot.ctx.textAlign = "center";
    slot.ctx.lineWidth = 8;
    slot.ctx.strokeStyle = "rgba(28,16,8,0.8)";
    slot.ctx.strokeText(text, 128, 54);
    slot.ctx.fillStyle = "#ffe08a";
    slot.ctx.fillText(text, 128, 54);
    slot.map.needsUpdate = true;
    slot.life = 1.15;
    slot.x = x;
    slot.y = y;
    slot.z = z;
    slot.sprite.visible = true;
  }

  function buildBoard(title: string, sub: string) {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = 256;
    const g = c.getContext("2d");
    if (!g) throw new Error("board");
    g.fillStyle = "#3b291c";
    g.fillRect(0, 0, 512, 256);
    g.strokeStyle = "#e7a322";
    g.lineWidth = 12;
    g.strokeRect(10, 10, 492, 236);
    g.fillStyle = "#f4ead8";
    g.font = "700 52px Liberation Sans, sans-serif";
    g.textAlign = "center";
    g.fillText(title, 256, 110);
    g.fillStyle = "#ffd36a";
    g.font = "700 36px Liberation Sans, sans-serif";
    g.fillText(sub, 256, 175);
    const map = track(new THREE.CanvasTexture(c));
    map.colorSpace = THREE.SRGBColorSpace;
    const board = new THREE.Mesh(
      track(new THREE.BoxGeometry(2.3, 1.15, 0.1)),
      track(new THREE.MeshStandardMaterial({ map, roughness: 0.8 })),
    );
    board.position.y = 1.55;
    board.castShadow = true;
    const pole = new THREE.Mesh(track(new THREE.CylinderGeometry(0.07, 0.09, 1.6, 6)), woodMat);
    pole.position.y = 0.7;
    pole.castShadow = true;
    const group = new THREE.Group();
    group.add(board, pole);
    return group;
  }

  function faceCamp(group: THREE.Group, x: number, z: number) {
    const y = heightAt(x, z);
    group.position.set(x, y, z);
    const len = Math.hypot(x, z) || 1;
    const cx = -x / len;
    const cz = -z / len;
    group.lookAt(x - cx, y + 1.2, z - cz);
  }

  const assistSign = buildBoard("БРИГАДА", "нанять");
  faceCamp(assistSign, ASSIST.x, ASSIST.z - 0.2);
  scene.add(assistSign);
  const sellSign = buildBoard("СДАЧА", "брёвна → ₽");
  faceCamp(sellSign, SELL.x - 1.6, SELL.z + 1.5);
  scene.add(sellSign);

  const fences: { group: THREE.Group; zone: "birch" | "cedar" }[] = [];
  for (const zone of ZONES) {
    if (zone.cost === 0) continue;
    const len = Math.hypot(zone.cx, zone.cz) || 1;
    const ux = zone.cx / len;
    const uz = zone.cz / len;
    const px = zone.cx - ux * zone.radius * 0.96;
    const pz = zone.cz - uz * zone.radius * 0.96;
    const sign = buildBoard(zone.title, `${fmt(zone.cost)} ₽`);
    faceCamp(sign, px, pz);
    scene.add(sign);
    const group = new THREE.Group();
    const tx = -uz;
    const tz = ux;
    for (let i = -3; i <= 3; i++) {
      const post = new THREE.Mesh(track(new THREE.CylinderGeometry(0.08, 0.1, 1.3, 6)), woodMat);
      post.position.set(px + tx * i * 1.15, heightAt(px, pz) + 0.65, pz + tz * i * 1.15);
      post.castShadow = true;
      group.add(post);
      if (i < 3) {
        const rail = new THREE.Mesh(track(new THREE.BoxGeometry(1.15, 0.08, 0.06)), woodMat);
        rail.position.set(px + tx * (i + 0.5) * 1.15, heightAt(px, pz) + 0.85, pz + tz * (i + 0.5) * 1.15);
        rail.lookAt(rail.position.x + tx, rail.position.y, rail.position.z + tz);
        group.add(rail);
      }
    }
    scene.add(group);
    fences.push({ group, zone: zone.id as "birch" | "cedar" });
  }

  function addBuildingBits() {
    const mill = new THREE.Group();
    const base = new THREE.Mesh(track(new THREE.BoxGeometry(4.2, 1.7, 3.2)), woodMat);
    base.position.y = 0.85;
    base.castShadow = true;
    base.receiveShadow = true;
    const roofA = new THREE.Mesh(track(new THREE.BoxGeometry(4.6, 0.18, 2.1)), darkMat);
    roofA.position.set(0, 1.95, -0.55);
    roofA.rotation.x = 0.45;
    roofA.castShadow = true;
    const roofB = new THREE.Mesh(track(new THREE.BoxGeometry(4.6, 0.18, 2.1)), darkMat);
    roofB.position.set(0, 1.95, 0.55);
    roofB.rotation.x = -0.45;
    roofB.castShadow = true;
    const chimney = new THREE.Mesh(track(new THREE.BoxGeometry(0.4, 1.1, 0.4)), darkMat);
    chimney.position.set(-1.4, 2.3, 0);
    const winMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xffc56b,
        emissive: 0xffa24a,
        emissiveIntensity: 0.7,
        roughness: 0.25,
      }),
    );
    const win = new THREE.Mesh(track(new THREE.BoxGeometry(0.7, 0.55, 0.08)), winMat);
    win.position.set(0.2, 1.15, 1.62);
    mill.add(base, roofA, roofB, chimney, win);
    mill.position.set(MILL.x, heightAt(MILL.x, MILL.z), MILL.z);
    scene.add(mill);

    const blade = new THREE.Mesh(track(new THREE.CylinderGeometry(0.55, 0.55, 0.06, 16)), metalMat);
    blade.rotation.x = Math.PI / 2;
    const saw = new THREE.Group();
    saw.add(blade);
    const table = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 0.7, 0.8)), woodMat);
    table.position.y = 0.35;
    saw.add(table);
    saw.position.set(MILL.x + 2.6, heightAt(MILL.x, MILL.z), MILL.z + 0.4);
    scene.add(saw);

    const truck = new THREE.Group();
    const cabin = new THREE.Mesh(track(new THREE.BoxGeometry(1.5, 1.3, 1.5)), blueMat);
    cabin.position.set(0, 1.15, 0.85);
    cabin.castShadow = true;
    const bed = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 0.7, 2.4)), darkMat);
    bed.position.set(0, 0.85, -0.9);
    bed.castShadow = true;
    const wheelGeo = track(new THREE.CylinderGeometry(0.32, 0.32, 0.24, 10));
    wheelGeo.rotateZ(Math.PI / 2);
    for (const [wx, wz] of [
      [-0.7, 0.7],
      [0.7, 0.7],
      [-0.7, -1.3],
      [0.7, -1.3],
    ] as const) {
      const w = new THREE.Mesh(wheelGeo, darkMat);
      w.position.set(wx, 0.32, wz);
      truck.add(w);
    }
    truck.add(cabin, bed);
    truck.position.set(SELL.x, heightAt(SELL.x, SELL.z), SELL.z);
    truck.rotation.y = Math.PI * 0.85;
    scene.add(truck);

    const ring = new THREE.Mesh(
      track(new THREE.RingGeometry(2.15, 2.45, 28)),
      track(new THREE.MeshBasicMaterial({ color: 0xf0c14a, transparent: true, opacity: 0.9, side: THREE.DoubleSide })),
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(SELL.x, heightAt(SELL.x, SELL.z) + 0.08, SELL.z);
    scene.add(ring);

    const tractorG = new THREE.Group();
    const body = new THREE.Mesh(track(new THREE.BoxGeometry(1.15, 0.7, 1.9)), blueMat);
    body.position.y = 0.95;
    body.castShadow = true;
    const cab = new THREE.Mesh(track(new THREE.BoxGeometry(1.05, 0.7, 1.05)), blueMat);
    cab.position.set(0, 1.55, -0.15);
    cab.castShadow = true;
    const glass = new THREE.Mesh(
      track(new THREE.BoxGeometry(0.92, 0.42, 0.9)),
      track(
        new THREE.MeshStandardMaterial({
          color: 0xb7e4f2,
          roughness: 0.08,
          metalness: 0.05,
          transparent: true,
          opacity: 0.55,
        }),
      ),
    );
    glass.position.set(0, 1.6, -0.15);
    const big = track(new THREE.CylinderGeometry(0.48, 0.48, 0.28, 12));
    big.rotateZ(Math.PI / 2);
    const small = track(new THREE.CylinderGeometry(0.28, 0.28, 0.22, 10));
    small.rotateZ(Math.PI / 2);
    const wheels: THREE.Mesh[] = [];
    for (const [x, z, geo] of [
      [-0.62, -0.55, big],
      [0.62, -0.55, big],
      [-0.55, 0.7, small],
      [0.55, 0.7, small],
    ] as const) {
      const w = new THREE.Mesh(geo, darkMat);
      w.position.set(x, geo === big ? 0.48 : 0.3, z);
      w.castShadow = true;
      tractorG.add(w);
      wheels.push(w);
    }
    const stack = new THREE.Mesh(track(new THREE.CylinderGeometry(0.06, 0.07, 0.45, 6)), darkMat);
    stack.position.set(0.4, 1.7, 0.55);
    tractorG.add(body, cab, glass, stack);
    scene.add(tractorG);

    const rocks = new THREE.InstancedMesh(
      track(new THREE.DodecahedronGeometry(0.7, 0)),
      track(new THREE.MeshStandardMaterial({ color: 0x8d8a84, roughness: 0.92 })),
      10,
    );
    const rockSpots = [
      [-20, 18],
      [18, 20],
      [-48, -30],
      [48, -28],
      [20, -40],
      [-16, -46],
      [40, 8],
      [-40, 16],
      [6, -20],
      [-8, 22],
    ];
    rockSpots.forEach(([x, z], i) => {
      dummy.position.set(x, heightAt(x, z) + 0.2, z);
      dummy.rotation.set(rng(), rng(), rng());
      const s = 0.6 + rng() * 0.9;
      dummy.scale.set(s, s * 0.7, s);
      dummy.updateMatrix();
      rocks.setMatrixAt(i, dummy.matrix);
    });
    rocks.castShadow = true;
    rocks.receiveShadow = true;
    scene.add(rocks);

    return { blade, ring, tractorG, wheels, chimney: mill.localToWorld(new THREE.Vector3(-1.4, 2.8, 0)) };
  }

  const props = addBuildingBits();
  const flashMat = track(new THREE.MeshBasicMaterial({ color: 0xfff4e4, transparent: true, opacity: 0, depthTest: false }));
  const flashQuad = new THREE.Mesh(track(new THREE.PlaneGeometry(2.4, 2.4)), flashMat);
  flashQuad.position.set(0, 0, -0.7);
  flashQuad.renderOrder = 10;
  camera.add(flashQuad);

  const birds = Array.from({ length: 3 }, (_, i) => {
    const g = new THREE.Group();
    const mat = track(new THREE.MeshStandardMaterial({ color: 0x2a3034, roughness: 0.55 }));
    const body = new THREE.Mesh(track(new THREE.SphereGeometry(0.1, 6, 5)), mat);
    body.scale.set(1, 0.55, 1.7);
    const wing = track(new THREE.BoxGeometry(0.42, 0.025, 0.14));
    const wl = new THREE.Mesh(wing, mat);
    const wr = new THREE.Mesh(wing, mat);
    wl.position.x = -0.26;
    wr.position.x = 0.26;
    g.add(body, wl, wr);
    scene.add(g);
    return { g, wl, wr, a: i * 2.1, r: 16 + i * 6, y: 8 + i * 1.4, speed: 0.25 + i * 0.05 };
  });

  function readAxis() {
    const has = (code: string) => (bus.injected ? bus.injected.includes(code) : keys.has(code));
    let ix = bus.injected ? 0 : bus.moveX;
    let iy = bus.injected ? 0 : bus.moveY;
    if (has("KeyA") || has("ArrowLeft")) ix -= 1;
    if (has("KeyD") || has("ArrowRight")) ix += 1;
    if (has("KeyW") || has("ArrowUp")) iy += 1;
    if (has("KeyS") || has("ArrowDown")) iy -= 1;
    return { ix, iy };
  }

  function cargoCount() {
    return cargo.pine + cargo.birch + cargo.cedar;
  }

  function step(dt: number) {
    for (const cmd of bus.drain()) handle(cmd);

    const canMove = phase === "play" && panel === "none" && hitstop <= 0;
    if (hitstop > 0) hitstop = Math.max(0, hitstop - dt);

    let mvx = 0;
    let mvz = 0;
    if (canMove) {
      let { ix, iy } = readAxis();
      const stick = Math.hypot(ix, iy);
      if (stick > 0.18) dest = null;
      else if (dest) {
        const dx = dest.x - player.x;
        const dz = dest.z - player.z;
        if (dx * dx + dz * dz < 0.25) dest = null;
        else {
          iy = dx * FWD_X + dz * FWD_Z;
          ix = dx * RIGHT_X + dz * RIGHT_Z;
        }
      }
      const len = Math.hypot(ix, iy);
      if (len > 1) {
        ix /= len;
        iy /= len;
      }
      const spd = len > 0.04 ? moveSpeed(save.boots) : 0;
      mvx = (FWD_X * iy + RIGHT_X * ix) * spd;
      mvz = (FWD_Z * iy + RIGHT_Z * ix) * spd;
      const next = constrain(player.x + mvx * dt, player.z + mvz * dt, 0.34);
      const ox = player.x;
      const oz = player.z;
      player.x = next.x;
      player.z = next.z;
      player.speed = Math.hypot(player.x - ox, player.z - oz) / dt;
      if (player.speed > 0.45) {
        const fvx = (player.x - ox) / dt;
        const fvz = (player.z - oz) / dt;
        player.yaw = damp(player.yaw, Math.atan2(-fvx, -fvz), 14, dt);
      }
    } else if (phase !== "play") {
      player.speed = 0;
    } else {
      player.speed = 0;
    }

    let chopping = false;
    let chopTree: Tree | null = null;
    if (phase === "play" && hitstop <= 0) {
      let best: Tree | null = null;
      let bestD = 2.25;
      if (focus >= 0) {
        const focused = trees[focus];
        if (focused && !focused.dead && zoneOpen(focused.species, save)) {
          const d = Math.hypot(focused.x - player.x, focused.z - player.z);
          if (d < 2.4) best = focused;
        }
      }
      if (!best) {
        for (const tree of trees) {
          if (tree.dead || !zoneOpen(tree.species, save)) continue;
          const d = Math.hypot(tree.x - player.x, tree.z - player.z);
          if (d < bestD) {
            bestD = d;
            best = tree;
          }
        }
      }
      chopping = Boolean(best) && player.speed < 1.4;
      chopTree = chopping ? best : null;
      if (chopTree && player.speed <= 0.45) {
        player.yaw = damp(
          player.yaw,
          Math.atan2(-(chopTree.x - player.x), -(chopTree.z - player.z)),
          14,
          dt,
        );
      }
      player.chopCd -= dt;
      if (chopping && chopTree && player.chopCd <= 0) {
        player.chopCd = swingTime(save.axe);
        player.chopAnim = 0.001;
        chopTree.hp -= axeDamage(save.axe);
        chopTree.flash = 1;
        chopTree.shake = 0.16;
        audio.chop();
        trauma = Math.min(1, trauma + (save.shake ? 0.12 : 0));
        burst(chopTree.x, chopTree.y + 1.2, chopTree.z, 7, chip, 2.2, 8, 0.35);
        if (chopTree.hp <= 0) fell(chopTree, "player");
      }
      if (player.chopAnim > 0) {
        player.chopAnim += dt / Math.max(0.2, swingTime(save.axe));
        if (player.chopAnim >= 1) player.chopAnim = chopping ? 0.001 : 0;
      }

      if (carryCount(save.carry) > 0 && (player.x - SELL.x) ** 2 + (player.z - SELL.z) ** 2 < 11) {
        const money = payoutBag(save.carry);
        if (money > 0) {
          audio.coin();
          popText(`+${fmt(money)} ₽`, player.x, 2.1, player.z);
          burst(SELL.x, 1.4, SELL.z, 14, gold, 2.6, 6, 0.6);
          checkQuests();
          commit();
          dirty = true;
        }
      }

      for (const drop of drops) {
        if (!drop.alive) continue;
        drop.vy -= 9 * dt;
        drop.y += drop.vy * dt;
        const gy = heightAt(drop.x, drop.z) + 0.12;
        if (drop.y < gy) {
          drop.y = gy;
          drop.vy *= -0.28;
        }
        drop.age += dt;
        const room = carryCap(save.pack) - carryCount(save.carry);
        if (room > 0 && (drop.x - player.x) ** 2 + (drop.z - player.z) ** 2 < 1.7) {
          save.carry[drop.species] += 1;
          drop.alive = false;
          dirty = true;
          continue;
        }
        if (drop.age > 22) {
          save.stock[drop.species] += 1;
          drop.alive = false;
          dirty = true;
        }
      }

      for (let i = 0; i < save.workers; i++) {
        const worker = workers[i];
        if (!worker) continue;
        worker.spawn = Math.min(1, worker.spawn + dt * 1.5);
        const speedW = 4.5;
        if (worker.carry >= workerCarryCap()) worker.state = "toSell";
        if (worker.state === "toTree") {
          if (worker.tree < 0 || trees[worker.tree]?.dead) {
            if (worker.tree >= 0 && trees[worker.tree]) trees[worker.tree]!.reserved = -1;
            worker.tree = pickTree(worker);
            worker.stuck = 0;
          }
          const target = trees[worker.tree];
          if (!target) {
            worker.state = worker.carry > 0 ? "toSell" : "toTree";
          } else {
            const dx = target.x - worker.x;
            const dz = target.z - worker.z;
            const dist = Math.hypot(dx, dz) || 1;
            if (dist < 1.7) worker.state = "chop";
            else {
              let sx = dx / dist;
              let sz = dz / dist;
              for (const tree of trees) {
                if (tree.dead) continue;
                const ax = worker.x - tree.x;
                const az = worker.z - tree.z;
                const dd = ax * ax + az * az;
                if (dd < 2.2 && dd > 0.01) {
                  const d = Math.sqrt(dd);
                  sx += (ax / d) * 0.8;
                  sz += (az / d) * 0.8;
                }
              }
              const sl = Math.hypot(sx, sz) || 1;
              worker.x += (sx / sl) * speedW * dt;
              worker.z += (sz / sl) * speedW * dt;
              worker.yaw = damp(worker.yaw, Math.atan2(-sx, -sz), 10, dt);
              worker.stuck += dt;
              if (worker.stuck > 6) {
                target.reserved = -1;
                worker.tree = -1;
                worker.stuck = 0;
              }
            }
          }
        } else if (worker.state === "chop") {
          const target = trees[worker.tree];
          if (!target || target.dead) {
            worker.state = worker.carry > 0 ? "toSell" : "toTree";
            worker.tree = -1;
          } else {
            worker.yaw = damp(worker.yaw, Math.atan2(-(target.x - worker.x), -(target.z - worker.z)), 10, dt);
            worker.chopCd -= dt;
            if (worker.chopAnim > 0) {
              worker.chopAnim += dt / 0.62;
              if (worker.chopAnim > 1) worker.chopAnim = 0;
            }
            if (worker.chopCd <= 0) {
              worker.chopCd = 0.62;
              worker.chopAnim = 0.001;
              target.hp -= 8;
              target.flash = 1;
              target.shake = 0.12;
              burst(target.x, target.y + 1.1, target.z, 4, chip, 1.6, 7, 0.3);
              if (target.hp <= 0) {
                fell(target, worker.id);
                worker.state = worker.carry > 0 ? "toSell" : "toTree";
                worker.tree = -1;
              }
            }
          }
        } else {
          const dx = SELL.x - worker.x;
          const dz = SELL.z - worker.z;
          const dist = Math.hypot(dx, dz) || 1;
          if (dist < 2.5) {
            if (worker.carry > 0) {
              const money = Math.round(worker.carry * logValue(worker.species, save.sawmill));
              save.money += money;
              save.earned += money;
              save.trips += 1;
              worker.carry = 0;
              audio.coin();
              popText(`+${fmt(money)} ₽`, worker.x, 2, worker.z);
              checkQuests();
              commit();
              dirty = true;
            }
            worker.state = "toTree";
          } else {
            worker.x += (dx / dist) * speedW * dt;
            worker.z += (dz / dist) * speedW * dt;
            worker.yaw = damp(worker.yaw, Math.atan2(-dx, -dz), 10, dt);
          }
        }
      }

      if (save.tractor > 0) {
        const cap = tractorCap(save.tractor);
        tractor.wait -= dt;
        if (tractor.leg === "park" && tractor.wait <= 0) {
          const depot = bestDepot();
          if (depot.worth > 0) {
            tractor.leg = "toDepot";
            tractor.tx = depot.x;
            tractor.tz = depot.z;
          }
        }
        if (tractor.leg !== "park") {
          const dx = tractor.tx - tractor.x;
          const dz = tractor.tz - tractor.z;
          const dist = Math.hypot(dx, dz);
          const sp = tractorSpeed(save.tractor);
          if (dist < 1.3) {
            if (tractor.leg === "toDepot") {
              for (const species of SPECIES_LIST) {
                while (cargoCount() < cap && save.stock[species] > 0) {
                  save.stock[species] -= 1;
                  cargo[species] += 1;
                }
              }
              for (const drop of drops) {
                if (!drop.alive || cargoCount() >= cap) continue;
                if ((drop.x - tractor.x) ** 2 + (drop.z - tractor.z) ** 2 < 16) {
                  cargo[drop.species] += 1;
                  drop.alive = false;
                }
              }
              tractor.leg = "toSell";
              tractor.tx = SELL.x + 2.2;
              tractor.tz = SELL.z - 1.4;
            } else {
              const money = payoutBag(cargo);
              if (money > 0) {
                audio.coin();
                popText(`+${fmt(money)} ₽`, tractor.x, 2.2, tractor.z);
                checkQuests();
                commit();
                dirty = true;
              }
              const depot = bestDepot();
              if (depot.worth > 0) {
                tractor.leg = "toDepot";
                tractor.tx = depot.x;
                tractor.tz = depot.z;
              } else {
                tractor.leg = "park";
                tractor.tx = PARK.x;
                tractor.tz = PARK.z;
                tractor.wait = 1.6;
              }
            }
          } else {
            tractor.x += (dx / dist) * sp * dt;
            tractor.z += (dz / dist) * sp * dt;
            tractor.yaw = damp(tractor.yaw, Math.atan2(-dx, -dz), 6, dt);
            tractor.roll += sp * dt * 3;
          }
        }
      }

      for (const tree of trees) {
        if (tree.flash > 0) tree.flash = Math.max(0, tree.flash - dt * 3.5);
        if (tree.shake > 0) tree.shake = Math.max(0, tree.shake - dt * 1.4);
        if (tree.falling) {
          tree.fall = Math.min(1, tree.fall + dt / 0.78);
          if (tree.fall >= 1) {
            tree.falling = false;
            tree.regrow = 16 + Math.random() * 12;
          }
        } else if (tree.dead) {
          tree.regrow -= dt;
          if (tree.regrow <= 0) {
            tree.dead = false;
            tree.hp = tree.maxHp;
            tree.fall = 0;
            tree.grow = 0;
            tree.reserved = -1;
          }
        } else if (tree.grow < 1) {
          tree.grow = Math.min(1, tree.grow + dt / 0.55);
        }
      }
    }

    chirpAcc += dt;
    if (chirpAcc > 7) {
      chirpAcc = 0;
      audio.chirp();
    }
    if (Math.random() < dt * 8) {
      burst(props.chimney.x, props.chimney.y, props.chimney.z, 1, smoke, 0.4, -0.4, 1.4);
    }

    for (let i = 0; i < MAX_P; i++) {
      if (!pAlive[i]) {
        pPos[i * 3 + 1] = -40;
        continue;
      }
      pLife[i] -= dt;
      if (pLife[i] <= 0) {
        pAlive[i] = 0;
        pPos[i * 3 + 1] = -40;
        continue;
      }
      pVel[i * 3 + 1] -= pGrav[i] * dt;
      pPos[i * 3] += pVel[i * 3] * dt;
      pPos[i * 3 + 1] += pVel[i * 3 + 1] * dt;
      pPos[i * 3 + 2] += pVel[i * 3 + 2] * dt;
    }
    pPosAttr.needsUpdate = true;
    pColAttr.needsUpdate = true;

    if (toast) {
      toastT -= dt;
      if (toastT <= 0) {
        toast = "";
        dirty = true;
      }
    }
    if (!toast && toastQ.length) {
      toast = toastQ.shift() ?? "";
      toastId += 1;
      toastT = 2.35;
      dirty = true;
    }

    persist.acc += dt;
    if (persist.dirty && persist.acc > 1.4 && phase === "play") {
      persist.acc = 0;
      persist.dirty = false;
      commit();
    }

    near = computeNear();
  }

  function pickTree(worker: Worker) {
    let best = -1;
    let bestD = 1e12;
    const scan = (respect: boolean) => {
      best = -1;
      bestD = 1e12;
      for (let i = 0; i < trees.length; i++) {
        const tree = trees[i];
        if (!tree || tree.dead || !zoneOpen(tree.species, save)) continue;
        if (respect && tree.reserved !== -1 && tree.reserved !== worker.id) continue;
        const d = (tree.x - worker.x) ** 2 + (tree.z - worker.z) ** 2;
        if (d < bestD) {
          bestD = d;
          best = i;
        }
      }
    };
    scan(true);
    if (best < 0) scan(false);
    if (best >= 0 && trees[best]) trees[best]!.reserved = worker.id;
    return best;
  }

  function bestDepot() {
    let x = ZONES[0]?.cx ?? 0;
    let z = ZONES[0]?.cz ?? 0;
    let worth = 0;
    for (const zone of ZONES) {
      if (!zoneOpen(zone.id, save)) continue;
      let value = save.stock[zone.id] * SPECIES_META[zone.id].value;
      for (const drop of drops) {
        if (!drop.alive || drop.species !== zone.id) continue;
        if ((drop.x - zone.cx) ** 2 + (drop.z - zone.cz) ** 2 < zone.radius * zone.radius) value += 10;
      }
      if (value > worth) {
        worth = value;
        x = zone.cx;
        z = zone.cz;
      }
    }
    return { x, z, worth };
  }

  function computeNear(): NearPrompt | null {
    if (phase !== "play") return null;
    const dSell = Math.hypot(player.x - SELL.x, player.z - SELL.z);
    const dMill = Math.hypot(player.x - MILL.x, player.z - MILL.z);
    const dAssist = Math.hypot(player.x - ASSIST.x, player.z - ASSIST.z);
    const dPark = Math.hypot(player.x - PARK.x, player.z - PARK.z);
    if (dSell < 3.6 && carryCount(save.carry) > 0) {
      return { kind: "sell", label: "Сдать", sub: "Брёвна у машины" };
    }
    if (dMill < 3.5 && stockCount(save.stock) > 0) {
      return { kind: "mill", label: "Склад", sub: `${stockCount(save.stock)} бр. забрать` };
    }
    if (!save.zones.birch) {
      const zone = ZONES[1];
      if (zone && Math.hypot(player.x - (zone.cx - zone.cx / (Math.hypot(zone.cx, zone.cz) || 1) * zone.radius), player.z - (zone.cz - zone.cz / (Math.hypot(zone.cx, zone.cz) || 1) * zone.radius)) < 4.2) {
        return { kind: "birch", label: "Открыть", sub: `${fmt(ZONE_COST.birch)} ₽` };
      }
    }
    if (!save.zones.cedar) {
      const zone = ZONES[2];
      if (zone) {
        const len = Math.hypot(zone.cx, zone.cz) || 1;
        const gx = zone.cx - (zone.cx / len) * zone.radius;
        const gz = zone.cz - (zone.cz / len) * zone.radius;
        if (Math.hypot(player.x - gx, player.z - gz) < 4.2) {
          return { kind: "cedar", label: "Открыть", sub: `${fmt(ZONE_COST.cedar)} ₽` };
        }
      }
    }
    if (dAssist < 2.8 && save.workers < LIMITS.workers) {
      const cost = workerCost(save.workers) ?? 0;
      return { kind: "hire", label: "Нанять", sub: `${fmt(cost)} ₽` };
    }
    if (dPark < 3.2 && save.tractor < LIMITS.tractor) {
      const cost = tractorCost(save.tractor) ?? 0;
      return { kind: "tractor", label: "Трактор", sub: `${fmt(cost)} ₽` };
    }
    return null;
  }

  function hint() {
    if (phase !== "play") return null;
    if (save.chops === 0) return "Подойди к сосне и постой рядом — топор работает сам";
    if (carryCount(save.carry) > 0 && save.trips === 0) return "Отнеси брёвна к синей машине с золотым кольцом";
    if (carryCount(save.carry) >= carryCap(save.pack)) return "Рюкзак полный — сдавай на пилораму";
    if (save.workers === 0 && save.money >= (workerCost(0) ?? 9999)) return "Хватит на помощника — кнопка «Бригада» или табличка у двора";
    if (!save.zones.birch && save.money >= ZONE_COST.birch) return "Можно открыть берёзовую рощу на карте";
    return null;
  }

  function buildSnap(): Snap {
    const lp = levelProgress(save.chops);
    const quests = QUESTS.map((quest) => ({
      id: quest.id,
      title: quest.title,
      detail: quest.detail,
      cur: Math.min(quest.goal, quest.cur(save)),
      goal: quest.goal,
      reward: quest.reward,
      done: save.claimed.includes(quest.id),
    }));
    const upgrades = (
      [
        ["axe", "Топор", save.axe, LIMITS.axe, save.axe >= LIMITS.axe ? "Рубит в полную силу" : `Удар ${axeDamage(save.axe)} → ${axeDamage(save.axe + 1)}`],
        ["boots", "Сапоги", save.boots, LIMITS.boots, `Скорость ${moveSpeed(save.boots).toFixed(1)} м/с`],
        ["pack", "Рюкзак", save.pack, LIMITS.pack, `Вмещает ${carryCap(save.pack)} брёвен`],
        ["workers", "Бригада", save.workers, LIMITS.workers, save.workers ? `${save.workers} на делянке` : "Сами рубят и носят"],
        ["tractor", "Трактор", save.tractor, LIMITS.tractor, save.tractor ? `Кузов ${tractorCap(save.tractor)} брёвен` : "Возит склад на пилораму"],
        ["sawmill", "Пилорама", save.sawmill, LIMITS.sawmill, `Цена +${Math.round(millBonus(save.sawmill) * 100)}%`],
      ] as const
    ).map(([id, title, level, max, effect]) => {
      const cost = costOf(id);
      return { id, title, level, max, effect, cost, affordable: cost != null && save.money >= cost };
    });
    return {
      phase,
      hasSave: hasSaveFlag,
      bootError: null,
      money: Math.round(save.money),
      level: lp.level,
      levelInto: lp.into,
      levelNeed: lp.need,
      carry: carryCount(save.carry),
      carryMax: carryCap(save.pack),
      carryBits: { ...save.carry },
      stock: stockCount(save.stock),
      quests,
      active: quests.filter((q) => !q.done).slice(0, 2),
      toast: toast || null,
      toastId,
      hint: hint(),
      near,
      panel,
      sound: save.sound,
      shake: save.shake,
      upgrades,
      zones: ZONES.map((zone) => ({
        id: zone.id,
        title: zone.title,
        blurb: zone.blurb,
        open: zoneOpen(zone.id, save),
        cost: zone.cost,
        affordable: save.money >= zone.cost,
        chops: save.chopsBy[zone.id],
        stock: save.stock[zone.id],
      })),
      chops: save.chops,
      earned: Math.round(save.earned),
      workers: save.workers,
    };
  }

  const camPos = new THREE.Vector3(SPAWN.x + CAM_XZ, CAM_Y, SPAWN.z + CAM_XZ);
  const look = new THREE.Vector3();
  const desired = new THREE.Vector3();
  const ahead = new THREE.Vector3();
  let visualT = 0;

  function render(dt: number) {
    visualT += dt;
    writeTrees(visualT);
    const moving = player.speed > 0.4;
    pose(hero, dt, moving, player.chopAnim, carryCount(save.carry));
    placeRig(hero, player.x, player.z, player.yaw);
    placeRig(foreman, ASSIST.x - 0.2, ASSIST.z + 1.15, 0.4);
    pose(foreman, dt, false, 0, 0);
    workers.forEach((worker, i) => {
      const rig = workerRigs[i];
      if (!rig) return;
      const active = i < save.workers;
      rig.root.visible = active && worker.spawn > 0.02;
      if (!active) return;
      rig.root.scale.setScalar(0.35 + 0.65 * Math.min(1, worker.spawn));
      const walking = worker.state !== "chop";
      pose(rig, dt, walking, worker.chopAnim, worker.carry);
      placeRig(rig, worker.x, worker.z, worker.yaw);
    });

    props.tractorG.position.set(tractor.x, heightAt(tractor.x, tractor.z), tractor.z);
    props.tractorG.rotation.y = tractor.yaw;
    for (const wheel of props.wheels) wheel.rotation.x = tractor.roll;
    props.blade.rotation.z += dt * (6 + save.sawmill * 2);
    const pulse = 1 + Math.sin(visualT * 3) * 0.04;
    props.ring.scale.set(pulse, pulse, pulse);

    for (const fence of fences) {
      const open = save.zones[fence.zone] ? -2.4 : 0;
      fence.group.position.y += (open - fence.group.position.y) * (1 - Math.exp(-3 * dt));
    }

    for (const bird of birds) {
      bird.a += dt * bird.speed;
      bird.g.position.set(Math.cos(bird.a) * bird.r, bird.y + Math.sin(bird.a * 2) * 0.4, Math.sin(bird.a) * bird.r - 8);
      bird.g.rotation.y = -bird.a + Math.PI / 2;
      const flap = Math.sin(visualT * 8 + bird.a) * 0.6;
      bird.wl.rotation.z = flap;
      bird.wr.rotation.z = -flap;
    }

    for (let i = 0; i < drops.length; i++) {
      const drop = drops[i];
      if (!drop || !drop.alive) {
        dummy.scale.setScalar(0.0001);
        dummy.position.set(0, -10, 0);
      } else {
        dummy.position.set(drop.x, drop.y, drop.z);
        dummy.rotation.set(0, drop.age, 0.4);
        dummy.scale.setScalar(1);
        logMesh.setColorAt(i, logColors[drop.species]);
      }
      dummy.updateMatrix();
      logMesh.setMatrixAt(i, dummy.matrix);
    }
    logMesh.instanceMatrix.needsUpdate = true;
    if (logMesh.instanceColor) logMesh.instanceColor.needsUpdate = true;

    for (const label of labelPool) {
      if (label.life <= 0) continue;
      label.life -= dt;
      label.y += dt * 0.7;
      label.sprite.position.set(label.x, label.y, label.z);
      label.sprite.material.opacity = Math.max(0, label.life);
      if (label.life <= 0) label.sprite.visible = false;
    }

    const py = heightAt(player.x, player.z);
    ahead.set(FWD_X, 0, FWD_Z).multiplyScalar(4.2);
    desired.set(player.x + CAM_XZ, py + CAM_Y, player.z + CAM_XZ);
    const k = phase === "play" ? 4.2 : 1.4;
    camPos.lerp(desired, 1 - Math.exp(-k * dt));
    if (phase !== "play") {
      camPos.x += Math.sin(visualT * 0.25) * 0.6;
      camPos.z += Math.cos(visualT * 0.22) * 0.6;
    }
    trauma = Math.max(0, trauma - dt * 1.7);
    const shake = save.shake ? trauma * trauma : 0;
    const sx = (noise1(visualT * 22) - 0.5) * 0.45 * shake;
    const sy = (noise1(visualT * 19 + 3) - 0.5) * 0.28 * shake;
    camera.position.set(camPos.x + sx, camPos.y + sy, camPos.z);
    look.set(player.x + ahead.x, py + 1.25, player.z + ahead.z);
    camera.lookAt(look);
    sun.position.set(player.x + 28, 48, player.z + 14);
    sun.target.position.set(player.x, py, player.z);
    rim.position.set(player.x - 20, 16, player.z - 10);
    flashAmt = Math.max(0, flashAmt - dt * 1.4);
    flashMat.opacity = flashAmt * (reduceMotion ? 0 : 0.45);

    pubAcc += dt;
    if (dirty || pubAcc > 0.12) {
      pubAcc = 0;
      dirty = false;
      const prevNear = bus.getSnapshot().near?.label;
      const prevMoney = bus.getSnapshot().money;
      const next = buildSnap();
      if (next.near?.label !== prevNear || next.money !== prevMoney) dirty = false;
      bus.publish(next);
    }
  }

  function noise1(t: number) {
    const x = Math.sin(t * 12.9898) * 43758.5453;
    return x - Math.floor(x);
  }

  function resize() {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    if (w < 2 || h < 2) return;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }

  const onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    keys.add(e.code);
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    if (e.code === "Escape") bus.push({ t: "panel", panel: "none" });
    if ((e.code === "KeyE" || e.code === "Space") && phase === "play") bus.push({ t: "interact" });
  };
  const onKeyUp = (e: KeyboardEvent) => keys.delete(e.code);
  const onBlur = () => keys.clear();
  const onPointer = (e: PointerEvent) => {
    if (phase !== "play" || panel !== "none" || e.button !== 0) return;
    audio.unlock();
    const rect = canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1,
    );
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(ndc, camera);
    const treeHits = raycaster.intersectObjects(treeMeshes, false);
    const groundHits = raycaster.intersectObject(ground, false);
    const treeHit = treeHits[0];
    if (treeHit && (!groundHits[0] || treeHit.distance < groundHits[0].distance + 1.4)) {
      const list = lists.get(treeHit.object);
      const tree = list?.[treeHit.instanceId ?? -1];
      if (tree && !tree.dead && zoneOpen(tree.species, save)) {
        const dx = player.x - tree.x;
        const dz = player.z - tree.z;
        const d = Math.hypot(dx, dz) || 1;
        dest = { x: tree.x + (dx / d) * 1.7, z: tree.z + (dz / d) * 1.7 };
        focus = tree.id;
        return;
      }
    }
    const gHit = groundHits[0];
    if (gHit) {
      dest = { x: gHit.point.x, z: gHit.point.z };
      focus = -1;
    }
  };
  const onVis = () => {
    if (document.hidden) {
      if (phase === "play") commit();
    } else audio.resume();
  };

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);
  canvas.addEventListener("pointerdown", onPointer);
  window.addEventListener("resize", resize);
  document.addEventListener("visibilitychange", onVis);
  const ro = new ResizeObserver(() => resize());
  ro.observe(canvas);
  resize();

  window.__controlsTest = {
    getYaw: () => player.yaw,
    getSpeed: () => player.speed,
    setKeys: (codes) => {
      bus.injected = codes;
    },
  };

  const timer = new THREE.Timer();
  timer.connect(document);
  let acc = 0;
  renderer.setAnimationLoop((stamp) => {
    if (isDead()) return;
    timer.update(stamp);
    const frame = Math.min(timer.getDelta(), 0.05);
    acc += frame;
    const STEP = 1 / 60;
    let guard = 0;
    while (acc >= STEP && guard < 4) {
      step(STEP);
      acc -= STEP;
      guard += 1;
    }
    render(frame || STEP);
  });

  bus.publish({ ...buildSnap(), hasSave: hasSaveFlag });

  return () => {
    renderer.setAnimationLoop(null);
    timer.dispose();
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    window.removeEventListener("blur", onBlur);
    canvas.removeEventListener("pointerdown", onPointer);
    window.removeEventListener("resize", resize);
    document.removeEventListener("visibilitychange", onVis);
    ro.disconnect();
    if (window.__controlsTest?.getYaw() === player.yaw) window.__controlsTest = undefined;
    for (const item of disposables) item.dispose();
    renderer.dispose();
    scene.clear();
  };
}
