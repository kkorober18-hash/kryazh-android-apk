import type { Species } from "./balance";

export type Panel = "none" | "upgrade" | "map" | "quest" | "menu";

export type UpgradeId = "axe" | "boots" | "pack" | "workers" | "tractor" | "sawmill";

export type Cmd =
  | { t: "start"; fresh: boolean }
  | { t: "panel"; panel: Panel }
  | { t: "buy"; id: UpgradeId }
  | { t: "unlock"; zone: "birch" | "cedar" }
  | { t: "travel"; zone: Species | "camp" }
  | { t: "sound"; on: boolean }
  | { t: "shake"; on: boolean }
  | { t: "reset" }
  | { t: "interact" };

export type UpgradeRow = {
  id: UpgradeId;
  title: string;
  level: number;
  max: number;
  effect: string;
  cost: number | null;
  affordable: boolean;
};

export type ZoneCard = {
  id: Species;
  title: string;
  blurb: string;
  open: boolean;
  cost: number;
  affordable: boolean;
  chops: number;
  stock: number;
};

export type QuestRow = {
  id: string;
  title: string;
  detail: string;
  cur: number;
  goal: number;
  reward: number;
  done: boolean;
};

export type NearPrompt = {
  kind: "sell" | "mill" | "hire" | "birch" | "cedar" | "tractor";
  label: string;
  sub: string;
};

export type Snap = {
  phase: "title" | "play";
  hasSave: boolean;
  bootError: string | null;
  money: number;
  level: number;
  levelInto: number;
  levelNeed: number;
  carry: number;
  carryMax: number;
  carryBits: Record<Species, number>;
  stock: number;
  quests: QuestRow[];
  active: QuestRow[];
  toast: string | null;
  toastId: number;
  hint: string | null;
  near: NearPrompt | null;
  panel: Panel;
  sound: boolean;
  shake: boolean;
  upgrades: UpgradeRow[];
  zones: ZoneCard[];
  chops: number;
  earned: number;
  workers: number;
};

const initial: Snap = {
  phase: "title",
  hasSave: false,
  bootError: null,
  money: 0,
  level: 1,
  levelInto: 0,
  levelNeed: 6,
  carry: 0,
  carryMax: 8,
  carryBits: { pine: 0, birch: 0, cedar: 0 },
  stock: 0,
  quests: [],
  active: [],
  toast: null,
  toastId: 0,
  hint: null,
  near: null,
  panel: "none",
  sound: true,
  shake: true,
  upgrades: [],
  zones: [],
  chops: 0,
  earned: 0,
  workers: 0,
};

const listeners = new Set<() => void>();
let current = initial;

export const bus = {
  moveX: 0,
  moveY: 0,
  injected: null as string[] | null,
  cmds: [] as Cmd[],
  subscribe(fn: () => void) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
  getSnapshot() {
    return current;
  },
  publish(next: Snap) {
    current = next;
    for (const fn of listeners) fn();
  },
  push(cmd: Cmd) {
    this.cmds.push(cmd);
  },
  drain() {
    const copy = this.cmds.slice();
    this.cmds.length = 0;
    return copy;
  },
};
