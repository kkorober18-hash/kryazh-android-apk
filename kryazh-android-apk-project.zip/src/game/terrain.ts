export const HALF = 75;

function hash(ix: number, iz: number) {
  let n = Math.imul(ix, 374761393) + Math.imul(iz, 668265263);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

export function noise(x: number, z: number) {
  const x0 = Math.floor(x);
  const z0 = Math.floor(z);
  const fx = x - x0;
  const fz = z - z0;
  const sx = fx * fx * (3 - 2 * fx);
  const sz = fz * fz * (3 - 2 * fz);
  const a = hash(x0, z0);
  const b = hash(x0 + 1, z0);
  const c = hash(x0, z0 + 1);
  const d = hash(x0 + 1, z0 + 1);
  return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz;
}

function smoothstep(t: number, a: number, b: number) {
  const x = Math.min(1, Math.max(0, (t - a) / (b - a)));
  return x * x * (3 - 2 * x);
}

/** World height in meters. Camp around the origin stays flat. */
export function heightAt(x: number, z: number) {
  const camp = Math.hypot(x, z);
  const mask = smoothstep(camp, 14, 21);
  let y = (noise(x * 0.05, z * 0.05) - 0.5) * 0.7;
  y += (noise(x * 0.13 + 8, z * 0.13) - 0.5) * 0.22;
  const cedar = Math.hypot(x, z + 50);
  if (cedar < 38) y += (1 - cedar / 38) ** 2 * 3.6;
  const edge = Math.max(Math.abs(x), Math.abs(z));
  if (edge > 64) y += (edge - 64) * 0.22;
  return y * mask;
}
