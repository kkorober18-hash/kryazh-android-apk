let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let musicBus: GainNode | null = null;
let sfxBus: GainNode | null = null;
let wind: AudioBufferSourceNode | null = null;
let musicOn = false;
let muted = false;

function ensure() {
  if (ctx) return ctx;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  ctx = new AC({ latencyHint: "interactive" });
  master = ctx.createGain();
  musicBus = ctx.createGain();
  sfxBus = ctx.createGain();
  master.gain.value = 1;
  musicBus.gain.value = 0.9;
  sfxBus.gain.value = 1;
  musicBus.connect(master);
  sfxBus.connect(master);
  master.connect(ctx.destination);
  return ctx;
}

export const audio = {
  unlock() {
    if (typeof window === "undefined") return;
    const ac = ensure();
    if (ac.state === "suspended") void ac.resume();
  },
  resume() {
    if (ctx && ctx.state === "suspended") void ctx.resume();
  },
  setMuted(on: boolean) {
    muted = on;
    if (!master || !ctx) return;
    master.gain.setTargetAtTime(on ? 0 : 1, ctx.currentTime, 0.03);
  },
  startAmbience() {
    this.unlock();
    if (!ctx || !musicBus || musicOn || muted) return;
    musicOn = true;
    const seconds = 2;
    const buffer = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let last = 0;
    for (let i = 0; i < data.length; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02;
      data[i] = last * 3.2;
    }
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    src.loop = true;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 420;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.045, ctx.currentTime + 1.2);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(musicBus);
    src.start();
    wind = src;
  },
  stopAmbience() {
    musicOn = false;
    try {
      wind?.stop();
    } catch {
      /* already stopped */
    }
    wind = null;
  },
  chop() {
    blip(180, 0.045, "square", 0.04, 90);
    noiseHit(0.05, 900, 0.08);
  },
  fall() {
    noiseHit(0.22, 180, 0.16);
    blip(70, 0.18, "sine", 0.08, 40);
  },
  coin() {
    blip(880, 0.07, "sine", 0.06, 660);
    window.setTimeout(() => blip(1320, 0.09, "sine", 0.05, 990), 70);
  },
  deny() {
    blip(140, 0.14, "triangle", 0.05, 90);
  },
  fanfare() {
    blip(523, 0.12, "triangle", 0.06, 400);
    window.setTimeout(() => blip(659, 0.12, "triangle", 0.06, 500), 110);
    window.setTimeout(() => blip(784, 0.2, "triangle", 0.06, 620), 220);
  },
  chirp() {
    if (muted || !ctx) return;
    blip(1400 + Math.random() * 800, 0.08, "sine", 0.015, 2200);
  },
};

function blip(
  freq: number,
  dur: number,
  type: OscillatorType,
  vol: number,
  endFreq: number,
) {
  if (muted || !ctx || !sfxBus) return;
  const t = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq), t + dur);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(vol, t + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(gain);
  gain.connect(sfxBus);
  osc.start(t);
  osc.stop(t + dur + 0.02);
  osc.onended = () => {
    osc.disconnect();
    gain.disconnect();
  };
}

function noiseHit(dur: number, freq: number, vol: number) {
  if (muted || !ctx || !sfxBus) return;
  const length = Math.floor(ctx.sampleRate * dur);
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
  const src = ctx.createBufferSource();
  src.buffer = buffer;
  const filter = ctx.createBiquadFilter();
  filter.type = "bandpass";
  filter.frequency.value = freq;
  filter.Q.value = 0.7;
  const gain = ctx.createGain();
  const t = ctx.currentTime;
  gain.gain.setValueAtTime(vol * (0.85 + Math.random() * 0.3), t);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  src.connect(filter);
  filter.connect(gain);
  gain.connect(sfxBus);
  src.playbackRate.value = 0.9 + Math.random() * 0.25;
  src.start(t);
  src.onended = () => {
    src.disconnect();
    filter.disconnect();
    gain.disconnect();
  };
}
