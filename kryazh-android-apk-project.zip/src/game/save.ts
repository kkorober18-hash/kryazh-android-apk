import { defaultSave, type Save, type Species } from "./balance";

const KEY = "kryazh-save-v1";

function num(v: unknown, fallback: number, max = 1e9) {
  if (typeof v !== "number" || !Number.isFinite(v)) return fallback;
  return Math.min(max, Math.max(0, v));
}

function bag(v: unknown): Record<Species, number> {
  const o = v && typeof v === "object" ? (v as Record<string, unknown>) : {};
  return {
    pine: num(o.pine, 0, 9999),
    birch: num(o.birch, 0, 9999),
    cedar: num(o.cedar, 0, 9999),
  };
}

export function loadSave(): Save | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<Save>;
    if (data.version !== 1) return null;
    const base = defaultSave();
    const zones = data.zones ?? base.zones;
    return {
      version: 1,
      money: num(data.money, 0),
      chops: num(data.chops, 0),
      chopsBy: bag(data.chopsBy),
      earned: num(data.earned, 0),
      trips: num(data.trips, 0),
      axe: Math.min(8, Math.max(1, Math.round(num(data.axe, 1, 8)))),
      boots: Math.min(6, Math.max(1, Math.round(num(data.boots, 1, 6)))),
      pack: Math.min(6, Math.max(1, Math.round(num(data.pack, 1, 6)))),
      workers: Math.min(5, Math.round(num(data.workers, 0, 5))),
      tractor: Math.min(4, Math.round(num(data.tractor, 0, 4))),
      sawmill: Math.min(5, Math.round(num(data.sawmill, 0, 5))),
      zones: {
        birch: Boolean(zones.birch),
        cedar: Boolean(zones.cedar),
      },
      claimed: Array.isArray(data.claimed)
        ? data.claimed.filter((id) => typeof id === "string")
        : [],
      carry: bag(data.carry),
      stock: bag(data.stock),
      sound: data.sound !== false,
      shake: data.shake !== false,
    };
  } catch {
    return null;
  }
}

export function writeSave(save: Save) {
  try {
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    /* private mode / quota — the session still plays */
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

export function hasSave() {
  return loadSave() !== null;
}
