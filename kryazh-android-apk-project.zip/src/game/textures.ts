import * as THREE from "three";
import { HALF, noise } from "./terrain";

function hash(ix: number, iz: number) {
  let n = Math.imul(ix, 1274126177) ^ Math.imul(iz, 374761393);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

function canvasTex(size: number, draw: (ctx: CanvasRenderingContext2D, size: number) => void) {
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("canvas");
  draw(ctx, size);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.needsUpdate = true;
  return tex;
}

function distSeg(px: number, pz: number, ax: number, az: number, bx: number, bz: number) {
  const abx = bx - ax;
  const abz = bz - az;
  const denom = abx * abx + abz * abz || 1;
  const t = Math.min(1, Math.max(0, ((px - ax) * abx + (pz - az) * abz) / denom));
  return Math.hypot(px - (ax + abx * t), pz - (az + abz * t));
}

export function makeTextures() {
  const ground = canvasTex(1024, (ctx, size) => {
    const img = ctx.createImageData(size, size);
    const d = img.data;
    const paths: [number, number][] = [
      [-30, -12],
      [32, -10],
      [1, -50],
    ];
    for (let py = 0; py < size; py++) {
      for (let px = 0; px < size; px++) {
        const u = px / (size - 1);
        const v = 1 - py / (size - 1);
        const x = -HALF + u * HALF * 2;
        const z = HALF - v * HALF * 2;
        const n = noise(x * 0.18, z * 0.18);
        const n2 = noise(x * 0.55 + 3, z * 0.55);
        const slope = Math.abs(noise(x * 0.08, z * 0.08) - noise((x + 2) * 0.08, z * 0.08));
        let r = 86 + n * 28;
        let g = 118 + n * 36;
        let b = 58 + n * 16;
        r += (n2 - 0.5) * 18;
        g += (n2 - 0.5) * 14;
        const camp = Math.hypot(x, z);
        const dirt = Math.min(1, Math.max(0, (15 - camp) / 7));
        let path = 0;
        for (const [bx, bz] of paths) {
          const ds = distSeg(x, z, 0, 2, bx, bz);
          path = Math.max(path, Math.min(1, (2.5 - ds) / 1.4));
        }
        const cedar = Math.max(0, 1 - Math.hypot(x, z + 50) / 34);
        const earth = Math.min(1, dirt * 0.95 + path * 0.85 + slope * 1.4);
        const er = 126;
        const eg = 96;
        const eb = 62;
        r = r * (1 - earth) + er * earth;
        g = g * (1 - earth) + eg * earth;
        b = b * (1 - earth) + eb * earth;
        g -= cedar * 18;
        r -= cedar * 10;
        b -= cedar * 6;
        const i = (py * size + px) * 4;
        d[i] = Math.max(0, Math.min(255, r));
        d[i + 1] = Math.max(0, Math.min(255, g));
        d[i + 2] = Math.max(0, Math.min(255, b));
        d[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  });
  ground.wrapS = THREE.ClampToEdgeWrapping;
  ground.wrapT = THREE.ClampToEdgeWrapping;

  const bark = canvasTex(256, (ctx, size) => {
    ctx.fillStyle = "#6a4632";
    ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 90; i++) {
      const x = (hash(i, 1) * size) | 0;
      ctx.fillStyle = hash(i, 2) > 0.5 ? "#5a3828" : "#7c5640";
      ctx.fillRect(x, 0, 2 + ((hash(i, 3) * 4) | 0), size);
    }
    for (let y = 0; y < size; y += 4) {
      for (let x = 0; x < size; x += 4) {
        const n = hash(x, y);
        if (n > 0.72) {
          ctx.fillStyle = `rgba(40,24,14,${0.15 + n * 0.3})`;
          ctx.fillRect(x, y, 3, 6 + ((n * 10) | 0));
        }
      }
    }
  });

  const birch = canvasTex(256, (ctx, size) => {
    ctx.fillStyle = "#e7e1d6";
    ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 14; i++) {
      const y = ((hash(i, 4) * size) | 0);
      ctx.fillStyle = `rgba(40,36,32,${0.35 + hash(i, 5) * 0.4})`;
      ctx.fillRect(0, y, size, 3 + ((hash(i, 6) * 5) | 0));
    }
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = "rgba(90,70,50,0.25)";
      ctx.fillRect((hash(i, 7) * size) | 0, (hash(i, 8) * size) | 0, 8, 2);
    }
  });

  const plank = canvasTex(256, (ctx, size) => {
    ctx.fillStyle = "#8a6244";
    ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 6; i++) {
      const y = (i / 6) * size;
      ctx.fillStyle = i % 2 ? "#7a563c" : "#946848";
      ctx.fillRect(0, y, size, size / 6 - 2);
      ctx.fillStyle = "rgba(50,30,16,0.45)";
      ctx.fillRect(0, y + size / 6 - 3, size, 3);
    }
    for (let i = 0; i < 30; i++) {
      ctx.strokeStyle = "rgba(60,36,18,0.35)";
      ctx.beginPath();
      const x = hash(i, 9) * size;
      ctx.moveTo(x, 0);
      ctx.lineTo(x + 6, size);
      ctx.stroke();
    }
  });

  const plaid = canvasTex(128, (ctx, size) => {
    ctx.fillStyle = "#9c2b2b";
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = "#6e1c1c";
    for (let i = 0; i < size; i += 16) ctx.fillRect(i, 0, 6, size);
    for (let i = 0; i < size; i += 16) ctx.fillRect(0, i, size, 6);
    ctx.fillStyle = "#d7d2c6";
    for (let i = 8; i < size; i += 16) ctx.fillRect(i, 0, 2, size);
    for (let i = 8; i < size; i += 16) ctx.fillRect(0, i, size, 2);
  });

  const soft = canvasTex(64, (ctx, size) => {
    const g = ctx.createRadialGradient(size / 2, size / 2, 2, size / 2, size / 2, size / 2);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.4, "rgba(255,255,255,0.7)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
  });
  soft.wrapS = THREE.ClampToEdgeWrapping;
  soft.wrapT = THREE.ClampToEdgeWrapping;

  return { ground, bark, birch, plank, plaid, soft };
}

export type TexSet = ReturnType<typeof makeTextures>;
