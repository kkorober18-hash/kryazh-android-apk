export type Species = "pine" | "birch" | "cedar";

export type Save = {
  version: 1;
  money: number;
  chops: number;
  chopsBy: Record<Species, number>;
  earned: number;
  trips: number;
  axe: number;
  boots: number;
  pack: number;
  workers: number;
  tractor: number;
  sawmill: number;
  zones: { birch: boolean; cedar: boolean };
  claimed: string[];
  carry: Record<Species, number>;
  stock: Record<Species, number>;
  sound: boolean;
  shake: boolean;
};

export const ZONE_COST = { birch: 480, cedar: 3600 } as const;

export const SPECIES_META: Record<
  Species,
  { name: string; value: number; hp: number; yield: number }
> = {
  pine: { name: "Сосна", value: 13, hp: 30, yield: 2 },
  birch: { name: "Берёза", value: 32, hp: 50, yield: 2 },
  cedar: { name: "Кедр", value: 78, hp: 84, yield: 3 },
};

export const LIMITS = {
  axe: 8,
  boots: 6,
  pack: 6,
  workers: 5,
  tractor: 4,
  sawmill: 5,
} as const;

const WORKER_COST = [150, 400, 900, 1800, 3400];
const TRACTOR_COST = [780, 1700, 3600, 7400];
const MILL_COST = [220, 620, 1500, 3400, 7600];

export function defaultSave(): Save {
  return {
    version: 1,
    money: 0,
    chops: 0,
    chopsBy: { pine: 0, birch: 0, cedar: 0 },
    earned: 0,
    trips: 0,
    axe: 1,
    boots: 1,
    pack: 1,
    workers: 0,
    tractor: 0,
    sawmill: 0,
    zones: { birch: false, cedar: false },
    claimed: [],
    carry: { pine: 0, birch: 0, cedar: 0 },
    stock: { pine: 0, birch: 0, cedar: 0 },
    sound: true,
    shake: true,
  };
}

export function axeCost(level: number) {
  return Math.round(50 * 1.78 ** (level - 1));
}
export function bootsCost(level: number) {
  return Math.round(45 * 1.7 ** (level - 1));
}
export function packCost(level: number) {
  return Math.round(75 * 1.74 ** (level - 1));
}
export function workerCost(count: number) {
  return WORKER_COST[count] ?? null;
}
export function tractorCost(level: number) {
  return TRACTOR_COST[level] ?? null;
}
export function millCost(level: number) {
  return MILL_COST[level] ?? null;
}

export function axeDamage(level: number) {
  return 10 + (level - 1) * 7;
}
export function swingTime(level: number) {
  return Math.max(0.28, 0.5 - (level - 1) * 0.028);
}
export function moveSpeed(level: number) {
  return 6.1 + (level - 1) * 0.46;
}
export function carryCap(level: number) {
  return 8 + (level - 1) * 5;
}
export function millBonus(level: number) {
  return level * 0.12;
}
export function tractorCap(level: number) {
  return level * 10;
}
export function tractorSpeed(level: number) {
  return 4.6 + level * 0.85;
}
export function workerCarryCap() {
  return 4;
}

export function logValue(species: Species, sawmill: number) {
  return SPECIES_META[species].value * (1 + millBonus(sawmill));
}

export function levelProgress(chops: number) {
  let level = 1;
  let need = 6;
  let rest = Math.max(0, chops);
  while (rest >= need && level < 40) {
    rest -= need;
    level += 1;
    need = Math.round(need * 1.38 + 2);
  }
  return { level, into: rest, need };
}

export type QuestDef = {
  id: string;
  title: string;
  detail: string;
  reward: number;
  goal: number;
  cur: (s: Save) => number;
};

export const QUESTS: QuestDef[] = [
  {
    id: "pine8",
    title: "Рубка сосен",
    detail: "Сруби 8 сосен",
    reward: 50,
    goal: 8,
    cur: (s) => s.chopsBy.pine,
  },
  {
    id: "trip1",
    title: "Первая отгрузка",
    detail: "Сдай брёвна на пилораму",
    reward: 70,
    goal: 1,
    cur: (s) => s.trips,
  },
  {
    id: "earn250",
    title: "Касса смены",
    detail: "Заработай 250 ₽ продажами",
    reward: 80,
    goal: 250,
    cur: (s) => s.earned,
  },
  {
    id: "hire",
    title: "Бригада",
    detail: "Найми первого помощника",
    reward: 90,
    goal: 1,
    cur: (s) => s.workers,
  },
  {
    id: "axe3",
    title: "Острый топор",
    detail: "Прокачай топор до 3 уровня",
    reward: 110,
    goal: 3,
    cur: (s) => s.axe,
  },
  {
    id: "birch",
    title: "Новая зона",
    detail: "Открой берёзовую рощу",
    reward: 180,
    goal: 1,
    cur: (s) => (s.zones.birch ? 1 : 0),
  },
  {
    id: "birch12",
    title: "Белые стволы",
    detail: "Сруби 12 берёз",
    reward: 240,
    goal: 12,
    cur: (s) => s.chopsBy.birch,
  },
  {
    id: "tractor",
    title: "Техника",
    detail: "Купи трактор",
    reward: 260,
    goal: 1,
    cur: (s) => (s.tractor >= 1 ? 1 : 0),
  },
  {
    id: "mill3",
    title: "Пилорама",
    detail: "Пилорама 3 уровня",
    reward: 320,
    goal: 3,
    cur: (s) => s.sawmill,
  },
  {
    id: "cedar",
    title: "Кедровый склон",
    detail: "Открой третью зону",
    reward: 480,
    goal: 1,
    cur: (s) => (s.zones.cedar ? 1 : 0),
  },
  {
    id: "crew",
    title: "Полная смена",
    detail: "Четверо помощников на делянке",
    reward: 520,
    goal: 4,
    cur: (s) => s.workers,
  },
  {
    id: "earn8k",
    title: "Крупный подряд",
    detail: "Заработай 8 000 ₽",
    reward: 900,
    goal: 8000,
    cur: (s) => s.earned,
  },
];

export function carryCount(c: Record<Species, number>) {
  return c.pine + c.birch + c.cedar;
}

export function stockCount(c: Record<Species, number>) {
  return c.pine + c.birch + c.cedar;
}

export function fmt(n: number) {
  return Math.max(0, Math.floor(n)).toLocaleString("ru-RU");
}
