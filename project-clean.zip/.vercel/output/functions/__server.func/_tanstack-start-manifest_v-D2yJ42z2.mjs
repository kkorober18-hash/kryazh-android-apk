//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D2yJ42z2.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/data/data/com.termux/files/home/project/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BX3vsIvZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BX3vsIvZ.js"
		} }]
	},
	"/": {
		filePath: "/data/data/com.termux/files/home/project/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dpgn6580.js"]
	}
} });
//#endregion
export { tsrStartManifest };
