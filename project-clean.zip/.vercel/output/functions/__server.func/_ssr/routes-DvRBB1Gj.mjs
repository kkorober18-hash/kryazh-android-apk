import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Users, c as Tractor, d as Hammer, f as Footprints, g as Axe, h as Backpack, i as Volume2, l as Menu, m as ClipboardList, n as Warehouse, p as Coins, r as VolumeX, s as TreePine, t as X, u as Map } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DvRBB1Gj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var ZONE_COST = {
	birch: 480,
	cedar: 3600
};
var SPECIES_META = {
	pine: {
		name: "Сосна",
		value: 13,
		hp: 30,
		yield: 2
	},
	birch: {
		name: "Берёза",
		value: 32,
		hp: 50,
		yield: 2
	},
	cedar: {
		name: "Кедр",
		value: 78,
		hp: 84,
		yield: 3
	}
};
var LIMITS = {
	axe: 8,
	boots: 6,
	pack: 6,
	workers: 5,
	tractor: 4,
	sawmill: 5
};
var WORKER_COST = [
	150,
	400,
	900,
	1800,
	3400
];
var TRACTOR_COST = [
	780,
	1700,
	3600,
	7400
];
var MILL_COST = [
	220,
	620,
	1500,
	3400,
	7600
];
function defaultSave() {
	return {
		version: 1,
		money: 0,
		chops: 0,
		chopsBy: {
			pine: 0,
			birch: 0,
			cedar: 0
		},
		earned: 0,
		trips: 0,
		axe: 1,
		boots: 1,
		pack: 1,
		workers: 0,
		tractor: 0,
		sawmill: 0,
		zones: {
			birch: false,
			cedar: false
		},
		claimed: [],
		carry: {
			pine: 0,
			birch: 0,
			cedar: 0
		},
		stock: {
			pine: 0,
			birch: 0,
			cedar: 0
		},
		sound: true,
		shake: true
	};
}
function axeCost(level) {
	return Math.round(50 * 1.78 ** (level - 1));
}
function bootsCost(level) {
	return Math.round(45 * 1.7 ** (level - 1));
}
function packCost(level) {
	return Math.round(75 * 1.74 ** (level - 1));
}
function workerCost(count) {
	return WORKER_COST[count] ?? null;
}
function tractorCost(level) {
	return TRACTOR_COST[level] ?? null;
}
function millCost(level) {
	return MILL_COST[level] ?? null;
}
function axeDamage(level) {
	return 10 + (level - 1) * 7;
}
function swingTime(level) {
	return Math.max(.28, .5 - (level - 1) * .028);
}
function moveSpeed(level) {
	return 6.1 + (level - 1) * .46;
}
function carryCap(level) {
	return 8 + (level - 1) * 5;
}
function millBonus(level) {
	return level * .12;
}
function tractorCap(level) {
	return level * 10;
}
function tractorSpeed(level) {
	return 4.6 + level * .85;
}
function workerCarryCap() {
	return 4;
}
function logValue(species, sawmill) {
	return SPECIES_META[species].value * (1 + millBonus(sawmill));
}
function levelProgress(chops) {
	let level = 1;
	let need = 6;
	let rest = Math.max(0, chops);
	while (rest >= need && level < 40) {
		rest -= need;
		level += 1;
		need = Math.round(need * 1.38 + 2);
	}
	return {
		level,
		into: rest,
		need
	};
}
var QUESTS = [
	{
		id: "pine8",
		title: "Рубка сосен",
		detail: "Сруби 8 сосен",
		reward: 50,
		goal: 8,
		cur: (s) => s.chopsBy.pine
	},
	{
		id: "trip1",
		title: "Первая отгрузка",
		detail: "Сдай брёвна на пилораму",
		reward: 70,
		goal: 1,
		cur: (s) => s.trips
	},
	{
		id: "earn250",
		title: "Касса смены",
		detail: "Заработай 250 ₽ продажами",
		reward: 80,
		goal: 250,
		cur: (s) => s.earned
	},
	{
		id: "hire",
		title: "Бригада",
		detail: "Найми первого помощника",
		reward: 90,
		goal: 1,
		cur: (s) => s.workers
	},
	{
		id: "axe3",
		title: "Острый топор",
		detail: "Прокачай топор до 3 уровня",
		reward: 110,
		goal: 3,
		cur: (s) => s.axe
	},
	{
		id: "birch",
		title: "Новая зона",
		detail: "Открой берёзовую рощу",
		reward: 180,
		goal: 1,
		cur: (s) => s.zones.birch ? 1 : 0
	},
	{
		id: "birch12",
		title: "Белые стволы",
		detail: "Сруби 12 берёз",
		reward: 240,
		goal: 12,
		cur: (s) => s.chopsBy.birch
	},
	{
		id: "tractor",
		title: "Техника",
		detail: "Купи трактор",
		reward: 260,
		goal: 1,
		cur: (s) => s.tractor >= 1 ? 1 : 0
	},
	{
		id: "mill3",
		title: "Пилорама",
		detail: "Пилорама 3 уровня",
		reward: 320,
		goal: 3,
		cur: (s) => s.sawmill
	},
	{
		id: "cedar",
		title: "Кедровый склон",
		detail: "Открой третью зону",
		reward: 480,
		goal: 1,
		cur: (s) => s.zones.cedar ? 1 : 0
	},
	{
		id: "crew",
		title: "Полная смена",
		detail: "Четверо помощников на делянке",
		reward: 520,
		goal: 4,
		cur: (s) => s.workers
	},
	{
		id: "earn8k",
		title: "Крупный подряд",
		detail: "Заработай 8 000 ₽",
		reward: 900,
		goal: 8e3,
		cur: (s) => s.earned
	}
];
function carryCount(c) {
	return c.pine + c.birch + c.cedar;
}
function stockCount(c) {
	return c.pine + c.birch + c.cedar;
}
function fmt(n) {
	return Math.max(0, Math.floor(n)).toLocaleString("ru-RU");
}
var ctx = null;
var master = null;
var musicBus = null;
var sfxBus = null;
var wind = null;
var musicOn = false;
var muted = false;
function ensure() {
	if (ctx) return ctx;
	ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: "interactive" });
	master = ctx.createGain();
	musicBus = ctx.createGain();
	sfxBus = ctx.createGain();
	master.gain.value = 1;
	musicBus.gain.value = .9;
	sfxBus.gain.value = 1;
	musicBus.connect(master);
	sfxBus.connect(master);
	master.connect(ctx.destination);
	return ctx;
}
var audio = {
	unlock() {
		if (typeof window === "undefined") return;
		const ac = ensure();
		if (ac.state === "suspended") ac.resume();
	},
	resume() {
		if (ctx && ctx.state === "suspended") ctx.resume();
	},
	setMuted(on) {
		muted = on;
		if (!master || !ctx) return;
		master.gain.setTargetAtTime(on ? 0 : 1, ctx.currentTime, .03);
	},
	startAmbience() {
		this.unlock();
		if (!ctx || !musicBus || musicOn || muted) return;
		musicOn = true;
		const buffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
		const data = buffer.getChannelData(0);
		let last = 0;
		for (let i = 0; i < data.length; i++) {
			const white = Math.random() * 2 - 1;
			last = (last + .02 * white) / 1.02;
			data[i] = last * 3.2;
		}
		const src = ctx.createBufferSource();
		src.buffer = buffer;
		src.loop = true;
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 420;
		const gain = ctx.createGain();
		gain.gain.setValueAtTime(0, ctx.currentTime);
		gain.gain.linearRampToValueAtTime(.045, ctx.currentTime + 1.2);
		src.connect(filter);
		filter.connect(gain);
		gain.connect(musicBus);
		src.start();
		wind = src;
	},
	stopAmbience() {
		musicOn = false;
		try {
			wind?.stop();
		} catch {}
		wind = null;
	},
	chop() {
		blip(180, .045, "square", .04, 90);
		noiseHit(.05, 900, .08);
	},
	fall() {
		noiseHit(.22, 180, .16);
		blip(70, .18, "sine", .08, 40);
	},
	coin() {
		blip(880, .07, "sine", .06, 660);
		window.setTimeout(() => blip(1320, .09, "sine", .05, 990), 70);
	},
	deny() {
		blip(140, .14, "triangle", .05, 90);
	},
	fanfare() {
		blip(523, .12, "triangle", .06, 400);
		window.setTimeout(() => blip(659, .12, "triangle", .06, 500), 110);
		window.setTimeout(() => blip(784, .2, "triangle", .06, 620), 220);
	},
	chirp() {
		if (muted || !ctx) return;
		blip(1400 + Math.random() * 800, .08, "sine", .015, 2200);
	}
};
function blip(freq, dur, type, vol, endFreq) {
	if (muted || !ctx || !sfxBus) return;
	const t = ctx.currentTime;
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, t);
	osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq), t + dur);
	gain.gain.setValueAtTime(1e-4, t);
	gain.gain.exponentialRampToValueAtTime(vol, t + .012);
	gain.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	osc.connect(gain);
	gain.connect(sfxBus);
	osc.start(t);
	osc.stop(t + dur + .02);
	osc.onended = () => {
		osc.disconnect();
		gain.disconnect();
	};
}
function noiseHit(dur, freq, vol) {
	if (muted || !ctx || !sfxBus) return;
	const length = Math.floor(ctx.sampleRate * dur);
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
	const src = ctx.createBufferSource();
	src.buffer = buffer;
	const filter = ctx.createBiquadFilter();
	filter.type = "bandpass";
	filter.frequency.value = freq;
	filter.Q.value = .7;
	const gain = ctx.createGain();
	const t = ctx.currentTime;
	gain.gain.setValueAtTime(vol * (.85 + Math.random() * .3), t);
	gain.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	src.connect(filter);
	filter.connect(gain);
	gain.connect(sfxBus);
	src.playbackRate.value = .9 + Math.random() * .25;
	src.start(t);
	src.onended = () => {
		src.disconnect();
		filter.disconnect();
		gain.disconnect();
	};
}
var initial = {
	phase: "title",
	hasSave: false,
	bootError: null,
	money: 0,
	level: 1,
	levelInto: 0,
	levelNeed: 6,
	carry: 0,
	carryMax: 8,
	carryBits: {
		pine: 0,
		birch: 0,
		cedar: 0
	},
	stock: 0,
	quests: [],
	active: [],
	toast: null,
	toastId: 0,
	hint: null,
	near: null,
	panel: "none",
	sound: true,
	shake: true,
	upgrades: [],
	zones: [],
	chops: 0,
	earned: 0,
	workers: 0
};
var listeners = /* @__PURE__ */ new Set();
var current = initial;
var bus = {
	moveX: 0,
	moveY: 0,
	injected: null,
	cmds: [],
	subscribe(fn) {
		listeners.add(fn);
		return () => listeners.delete(fn);
	},
	getSnapshot() {
		return current;
	},
	publish(next) {
		current = next;
		for (const fn of listeners) fn();
	},
	push(cmd) {
		this.cmds.push(cmd);
	},
	drain() {
		const copy = this.cmds.slice();
		this.cmds.length = 0;
		return copy;
	}
};
var ICONS = {
	axe: Axe,
	boots: Footprints,
	pack: Backpack,
	workers: Users,
	tractor: Tractor,
	sawmill: Warehouse
};
function Hud() {
	const snap = (0, import_react.useSyncExternalStore)(bus.subscribe, bus.getSnapshot, bus.getSnapshot);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hud",
		children: [snap.phase === "title" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, { snap }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { snap }), snap.panel !== "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, { snap }) : null]
	});
}
function Title({ snap }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "title-screen",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "title-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Лесопильный бизнес"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Кряж" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lede",
					children: "Руби лес, продавай брёвна, открывай новые делянки и расти бригаду."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "steps",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePine, {}), "Подойди к дереву — рубка начинается сама."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, {}), "Отнеси брёвна к синей машине и получи деньги."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, {}), "Копи на берёзу и кедр, нанимай людей и трактор."] })
					]
				}),
				snap.bootError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "boot-error",
					children: snap.bootError
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "btn-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "primary",
						type: "button",
						onClick: () => {
							audio.unlock();
							bus.push({
								t: "start",
								fresh: !snap.hasSave
							});
						},
						children: snap.hasSave ? "Продолжить смену" : "Начать смену"
					}), snap.hasSave ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ghost",
						type: "button",
						onClick: () => {
							audio.unlock();
							bus.push({
								t: "start",
								fresh: true
							});
						},
						children: "Новая делянка"
					}) : null]
				})
			]
		})
	});
}
function Play({ snap }) {
	const [pop, setPop] = (0, import_react.useState)(false);
	const prev = (0, import_react.useRef)(snap.money);
	(0, import_react.useEffect)(() => {
		if (snap.money !== prev.current) {
			prev.current = snap.money;
			setPop(true);
			const id = window.setTimeout(() => setPop(false), 220);
			return () => window.clearTimeout(id);
		}
	}, [snap.money]);
	const pct = Math.max(0, Math.min(100, snap.levelInto / Math.max(1, snap.levelNeed) * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "topbar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "level-wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "level-badge",
					"aria-label": `Уровень ${snap.level}`,
					children: snap.level
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "level-meta",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Уровень" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "level-track",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { width: `${pct}%` } })
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: pop ? "money pop" : "money",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, {}),
					fmt(snap.money),
					" ₽"
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "quests",
			children: snap.active.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "quest",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {}), "Смена закрыта"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Все подрядные задания выполнены. Лес всё ещё приносит деньги." })]
			}) : snap.active.map((quest) => {
				const qpct = Math.max(0, Math.min(100, quest.cur / Math.max(1, quest.goal) * 100));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "quest",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {}), quest.title] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: quest.detail }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { width: `${qpct}%` } })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "count",
							children: [
								quest.cur,
								"/",
								quest.goal
							]
						})
					]
				}, quest.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rail",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "rail-btn",
					type: "button",
					onClick: () => bus.push({
						t: "panel",
						panel: "upgrade"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Апгрейд" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "rail-btn",
					type: "button",
					onClick: () => bus.push({
						t: "panel",
						panel: "map"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Карта" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "rail-btn",
					type: "button",
					onClick: () => bus.push({
						t: "panel",
						panel: "quest"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Задания" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "rail-btn",
					type: "button",
					onClick: () => bus.push({
						t: "panel",
						panel: "menu"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Меню" })]
				})
			]
		}),
		snap.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hint",
			children: snap.hint
		}) : null,
		snap.toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "toast",
			children: snap.toast
		}, snap.toastId) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bottom-bar",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Joystick, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "carry",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
							snap.carry,
							"/",
							snap.carryMax
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: snap.stock > 0 ? `рюкзак · склад ${snap.stock}` : "в рюкзаке" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "dots",
							"aria-hidden": "true",
							children: [
								snap.carryBits.pine > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "pine" }) : null,
								snap.carryBits.birch > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "birch" }) : null,
								snap.carryBits.cedar > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "cedar" }) : null
							]
						})
					]
				}),
				snap.near ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "act-btn",
					type: "button",
					onClick: () => bus.push({ t: "interact" }),
					children: [snap.near.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: snap.near.sub })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "keys",
			children: "WASD — ходить · клик по дереву · E — действие"
		})
	] });
}
function Joystick() {
	const ref = (0, import_react.useRef)(null);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const move = (clientX, clientY) => {
		const node = ref.current;
		if (!node) return;
		const rect = node.getBoundingClientRect();
		const cx = rect.left + rect.width / 2;
		const cy = rect.top + rect.height / 2;
		let dx = clientX - cx;
		let dy = clientY - cy;
		const max = rect.width / 2;
		const len = Math.hypot(dx, dy) || 1;
		const clamped = Math.min(len, max);
		dx = dx / len * clamped;
		dy = dy / len * clamped;
		bus.moveX = dx / max;
		bus.moveY = -dy / max;
		setKnob({
			x: dx,
			y: dy
		});
	};
	const end = () => {
		bus.moveX = 0;
		bus.moveY = 0;
		setKnob({
			x: 0,
			y: 0
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "joy",
		ref,
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			audio.unlock();
			move(e.clientX, e.clientY);
		},
		onPointerMove: (e) => {
			if (e.currentTarget.hasPointerCapture(e.pointerId)) move(e.clientX, e.clientY);
		},
		onPointerUp: end,
		onPointerCancel: end,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "joy-knob",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		})
	});
}
function Sheet({ snap }) {
	const [armed, setArmed] = (0, import_react.useState)(false);
	const title = snap.panel === "upgrade" ? "Апгрейды" : snap.panel === "map" ? "Делянки" : snap.panel === "quest" ? "Задания" : "Меню";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sheet-back",
		onClick: () => bus.push({
			t: "panel",
			panel: "none"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet",
			role: "dialog",
			"aria-label": title,
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sheet-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "icon-btn",
						type: "button",
						"aria-label": "Закрыть",
						onClick: () => bus.push({
							t: "panel",
							panel: "none"
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				snap.panel === "upgrade" ? snap.upgrades.map((row) => {
					const Icon = ICONS[row.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "row-ico",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "row-copy",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: row.title }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: row.effect }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pips",
										"aria-hidden": "true",
										children: Array.from({ length: row.max }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: i < row.level ? "on" : "" }, i))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "price",
								type: "button",
								disabled: row.cost == null,
								onClick: () => bus.push({
									t: "buy",
									id: row.id
								}),
								children: row.cost == null ? "Макс." : `${fmt(row.cost)} ₽`
							})
						]
					}, row.id);
				}) : null,
				snap.panel === "map" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [snap.zones.map((zone) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "zone-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `zone-swatch ${zone.open ? zone.id : "locked"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePine, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "zone-copy",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: zone.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								zone.blurb,
								zone.open ? ` · срублено ${zone.chops}` : "",
								zone.stock > 0 ? ` · склад ${zone.stock}` : ""
							] })]
						}),
						zone.open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "price",
							type: "button",
							onClick: () => bus.push({
								t: "travel",
								zone: zone.id
							}),
							children: "Перейти"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "price",
							type: "button",
							onClick: () => {
								if (zone.id === "birch" || zone.id === "cedar") bus.push({
									t: "unlock",
									zone: zone.id
								});
							},
							children: [fmt(zone.cost), " ₽"]
						})
					]
				}, zone.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "btn-row sheet-gap",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ghost",
						type: "button",
						onClick: () => bus.push({
							t: "travel",
							zone: "camp"
						}),
						children: "Вернуться на базу"
					})
				})] }) : null,
				snap.panel === "quest" ? snap.quests.map((quest) => {
					const qpct = Math.max(0, Math.min(100, quest.cur / Math.max(1, quest.goal) * 100));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "row-copy",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [quest.done ? "Готово · " : "", quest.title] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									quest.detail,
									" · награда ",
									fmt(quest.reward),
									" ₽"
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bar",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { width: `${qpct}%` } })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "count",
							children: [
								quest.cur,
								"/",
								quest.goal
							]
						})]
					}, quest.id);
				}) : null,
				snap.panel === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "menu-block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "stat-line",
							children: [
								"Срублено ",
								snap.chops,
								" деревьев. Заработано ",
								fmt(snap.earned),
								" ₽. В бригаде ",
								snap.workers,
								". Прогресс хранится на этом устройстве."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "menu-btn",
							type: "button",
							onClick: () => bus.push({
								t: "sound",
								on: !snap.sound
							}),
							children: [
								snap.sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {}),
								" ",
								snap.sound ? "Звук включён" : "Звук выключен"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "menu-btn",
							type: "button",
							onClick: () => bus.push({
								t: "shake",
								on: !snap.shake
							}),
							children: snap.shake ? "Тряска камеры включена" : "Тряска камеры выключена"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "menu-btn",
							type: "button",
							onClick: () => {
								if (!armed) {
									setArmed(true);
									return;
								}
								bus.push({ t: "reset" });
							},
							children: armed ? "Точно сбросить прогресс" : "Сбросить прогресс"
						})
					]
				}) : null
			]
		})
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		let stop = () => {};
		let cancel = false;
		import("./engine-CI2ldO8b.mjs").then((mod) => {
			if (cancel) return;
			stop = mod.mount(canvas);
		});
		return () => {
			cancel = true;
			stop();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "game-root",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref,
			className: "game-canvas"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {})]
	});
}
//#endregion
export { tractorCap as C, workerCost as D, workerCarryCap as E, swingTime as S, tractorSpeed as T, millBonus as _, QUESTS as a, packCost as b, axeCost as c, carryCap as d, carryCount as f, logValue as g, levelProgress as h, LIMITS as i, axeDamage as l, fmt as m, bus as n, SPECIES_META as o, defaultSave as p, audio as r, ZONE_COST as s, routes_exports as t, bootsCost as u, millCost as v, tractorCost as w, stockCount as x, moveSpeed as y };
